<?php
declare(strict_types=1);
logoutUser();
jsonSuccess(null,'Logged out');
