<?php
declare(strict_types=1);
$d = getJsonBody();
$v = Validator::make($d)->required('name')->required('email')->email('email')->required('password')->min('password',6);
if($v->fails()) jsonError('Validation failed',422,$v->errors());
$um = new UserModel();
if($um->findByEmail($d['email'])) jsonError('Email already registered',409);
$d['password'] = password_hash($d['password'], PASSWORD_BCRYPT);
$user = $um->create($d);
unset($user['password']);
setCurrentUser($user);
jsonSuccess($user,'Registered successfully',201);
