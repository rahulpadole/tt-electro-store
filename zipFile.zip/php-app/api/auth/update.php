<?php
declare(strict_types=1);
requireLogin();
$d = getJsonBody();
$user = (new UserModel())->update(getCurrentUserId(), $d);
if(!$user) jsonError('Update failed',500);
setCurrentUser($user);
jsonSuccess($user,'Profile updated');
