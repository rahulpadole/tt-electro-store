<?php declare(strict_types=1);
$om=new OrderModel(); $uid=getCurrentUserId();
if(isGet()){
    requireLogin();
    jsonSuccess($om->getForUser($uid));
}
if(isPost()){
    requireLogin();
    $d=getJsonBody();
    $v=Validator::make($d)->required('items')->required('total')->required('shipping_address');
    if($v->fails()) jsonError('Validation failed',422,$v->errors());
    $d['user_id']=$uid;
    $order=$om->create($d);
    // Clear cart after order
    (new CartModel())->clearCart($uid);
    jsonSuccess($order,'Order placed',201);
}
jsonError('Method not allowed',405);
