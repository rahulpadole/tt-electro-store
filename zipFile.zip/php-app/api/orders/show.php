<?php declare(strict_types=1);
$om=new OrderModel(); $id=(int)($_GET['id']??0);
if(isGet()){
    requireLogin();
    $order=$om->findById($id);
    if(!$order) jsonError('Not found',404);
    if($order['user_id']!=getCurrentUserId() && !isAdmin()) jsonError('Forbidden',403);
    jsonSuccess($order);
}
if(isPatch()){
    requireAdmin();
    $d=getJsonBody();
    $order=$om->updateStatus($id,$d['status']??'');
    if(!$order) jsonError('Not found',404);
    jsonSuccess($order,'Updated');
}
jsonError('Method not allowed',405);
