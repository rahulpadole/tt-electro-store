<?php declare(strict_types=1);
$wm=new WishlistModel(); $uid=getCurrentUserId();
if(isGet()) jsonSuccess($wm->getForUser($uid));
if(isPost()){
    $d=getJsonBody();
    $v=Validator::make($d)->required('product_id');
    if($v->fails()) jsonError('Validation failed',422,$v->errors());
    jsonSuccess($wm->add($uid,(int)$d['product_id']),'Added',201);
}
jsonError('Method not allowed',405);
