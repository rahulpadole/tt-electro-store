<?php declare(strict_types=1);
$wm=new WishlistModel(); $uid=getCurrentUserId(); $pid=(int)($_GET['product_id']??0);
if(isDelete()){$wm->remove($uid,$pid);jsonSuccess(null,'Removed');}
jsonError('Method not allowed',405);
