<?php
declare(strict_types=1);

class UserModel {
    private PDO $db;
    public function __construct() { $this->db = Database::getConnection(); }

    public function findById(int $id): ?array {
        $st = $this->db->prepare('SELECT id,name,email,phone,avatar,role,loyalty_points,is_active,created_at FROM users WHERE id=?');
        $st->execute([$id]);
        return $st->fetch() ?: null;
    }

    public function findByEmail(string $email): ?array {
        $st = $this->db->prepare('SELECT * FROM users WHERE email=? LIMIT 1');
        $st->execute([$email]);
        return $st->fetch() ?: null;
    }

    public function create(array $data): array {
        $st = $this->db->prepare(
            'INSERT INTO users (name,email,password,phone,role) VALUES (?,?,?,?,?)'
        );
        $st->execute([
            $data['name'],
            $data['email'],
            $data['password'],
            $data['phone'] ?? null,
            $data['role'] ?? 'user',
        ]);
        $id = (int)$this->db->lastInsertId();
        return $this->findById($id);
    }

    public function update(int $id, array $data): ?array {
        $fields = []; $vals = [];
        foreach (['name','phone','avatar'] as $f) {
            if (array_key_exists($f, $data)) { $fields[] = "{$f}=?"; $vals[] = $data[$f]; }
        }
        if (empty($fields)) return $this->findById($id);
        $vals[] = $id;
        $st = $this->db->prepare('UPDATE users SET ' . implode(',', $fields) . ',updated_at=NOW() WHERE id=?');
        $st->execute($vals);
        return $this->findById($id);
    }

    public function all(int $limit = 100, int $offset = 0): array {
        $st = $this->db->prepare('SELECT id,name,email,phone,role,loyalty_points,is_active,created_at FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?');
        $st->execute([$limit, $offset]);
        return $st->fetchAll();
    }

    public function count(): int {
        return (int)$this->db->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }
}
