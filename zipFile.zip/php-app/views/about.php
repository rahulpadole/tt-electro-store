<?php $pageTitle = 'About Us'; ?>
<div class="max-w-4xl mx-auto px-4 py-8">
  <div class="text-center mb-12">
    <div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white font-bold text-3xl mx-auto mb-4">TT</div>
    <h1 class="text-3xl font-bold text-white mb-3">About TT Electro Store</h1>
    <p class="text-gray-400 max-w-xl mx-auto">We're on a mission to empower India's maker community with premium electronics, tools, and knowledge.</p>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
    <?php foreach([['🎯','Our Mission','To make premium electronics accessible to every maker, engineer, and DIY enthusiast across India.'],['👁️','Our Vision','To become India\'s most trusted electronics marketplace for the next generation of innovators.'],['💡','Our Values','Quality first, community-driven, and committed to education and innovation.']] as [$icon,$title,$text]): ?>
    <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-6 text-center">
      <div class="text-4xl mb-3"><?= $icon ?></div>
      <h2 class="font-bold text-white mb-2"><?= $title ?></h2>
      <p class="text-gray-400 text-sm leading-relaxed"><?= $text ?></p>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-8 mb-8">
    <h2 class="text-xl font-bold text-white mb-4">Our Story</h2>
    <div class="text-gray-400 text-sm leading-relaxed space-y-3">
      <p>TT Electro Store was founded by a team of engineers and makers who were frustrated with the lack of quality electronics suppliers in India. We started in a small garage in Bangalore, driven by a passion for electronics and making.</p>
      <p>Today, we serve thousands of customers across India – from hobbyists building their first Arduino project to professional engineers designing complex systems. Our curated selection of components, tools, and kits ensures you always get the right part for your project.</p>
      <p>We're more than just a store. We're a community of makers helping each other build amazing things. Join us on this journey!</p>
    </div>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    <?php foreach([['5000+','Happy Customers'],['10000+','Products'],['50+','Brands'],['99%','Satisfaction']] as [$num,$label]): ?>
    <div class="text-center rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-4">
      <p class="text-3xl font-bold text-blue-400"><?= $num ?></p>
      <p class="text-gray-400 text-sm mt-1"><?= $label ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</div>
