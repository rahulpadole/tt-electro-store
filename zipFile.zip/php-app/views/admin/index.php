<?php
$pageTitle = 'Dashboard';
$om = new OrderModel(); $pm = new ProductModel(); $um = new UserModel(); $nm = new NewsletterModel();
$totalOrders   = $om->count();
$totalRevenue  = $om->totalRevenue();
$totalProducts = $pm->count();
$totalUsers    = $um->count();
$subscribers   = $nm->count();
$recentOrders  = $om->all(5,0);
$topProducts   = $om->topProducts(5);
$revenueByMonth= $om->revenueByMonth();
$salesByCat    = $om->salesByCategory();
$lowStock      = $pm->lowStock(5);
$statusColors  = ['pending'=>'yellow','processing'=>'blue','shipped'=>'purple','delivered'=>'green','cancelled'=>'red'];
?>
<!-- Stats Cards -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
  <?php foreach([['Total Revenue','₹'.number_format($totalRevenue,0),'💰','text-green-400','from last month','bg-green-500/10'],['Total Orders',$totalOrders,'📦','text-blue-400','all time','bg-blue-500/10'],['Products',$totalProducts,'🛍️','text-purple-400','active','bg-purple-500/10'],['Customers',$totalUsers,'👥','text-cyan-400','registered','bg-cyan-500/10']] as [$label,$val,$icon,$color,$sub,$bg]): ?>
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-5">
    <div class="flex items-center justify-between mb-3">
      <p class="text-xs text-gray-500 font-medium uppercase tracking-wide"><?= $label ?></p>
      <span class="text-xl w-9 h-9 rounded-xl <?= $bg ?> flex items-center justify-center"><?= $icon ?></span>
    </div>
    <p class="text-2xl font-bold <?= $color ?>"><?= $val ?></p>
    <p class="text-xs text-gray-500 mt-1"><?= $sub ?></p>
  </div>
  <?php endforeach; ?>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
  <!-- Revenue Chart -->
  <div class="lg:col-span-2 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-5">
    <h2 class="font-semibold text-white mb-4">Revenue (Last 12 Months)</h2>
    <canvas id="revenueChart" height="100"></canvas>
  </div>
  <!-- Sales by Category -->
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-5">
    <h2 class="font-semibold text-white mb-4">Sales by Category</h2>
    <canvas id="catChart" height="180"></canvas>
  </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <!-- Recent Orders -->
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-5">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold text-white">Recent Orders</h2>
      <a href="/admin/orders" class="text-xs text-blue-400 hover:text-blue-300">View All →</a>
    </div>
    <div class="space-y-3">
      <?php foreach($recentOrders as $order):
        $sc = $statusColors[$order['status']] ?? 'gray';
      ?>
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm font-medium text-white"><?= clean($order['order_number']) ?></p>
          <p class="text-xs text-gray-500"><?= clean($order['user_name']??'') ?> · <?= date('M j',strtotime($order['created_at'])) ?></p>
        </div>
        <div class="flex items-center gap-3">
          <span class="px-2 py-0.5 rounded-full text-xs bg-<?= $sc ?>-500/20 text-<?= $sc ?>-400 capitalize"><?= clean($order['status']) ?></span>
          <span class="text-sm font-semibold text-white">₹<?= number_format((float)$order['total'],0) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Low Stock Alert -->
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-5">
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold text-white">⚠️ Low Stock</h2>
      <a href="/admin/inventory" class="text-xs text-blue-400 hover:text-blue-300">View Inventory →</a>
    </div>
    <?php if(empty($lowStock)): ?>
    <p class="text-gray-500 text-sm">All products have healthy stock levels!</p>
    <?php else: ?>
    <div class="space-y-3">
      <?php foreach($lowStock as $p): ?>
      <div class="flex items-center gap-3">
        <?php if($p['thumbnail']): ?><img src="<?= clean($p['thumbnail']) ?>" class="w-8 h-8 rounded-lg object-cover flex-shrink-0"><?php else: ?><div class="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-base flex-shrink-0">📦</div><?php endif; ?>
        <div class="flex-1 min-w-0">
          <p class="text-sm text-gray-200 truncate"><?= clean($p['name']) ?></p>
        </div>
        <span class="px-2 py-0.5 rounded-full text-xs <?= $p['stock']<=0?'bg-red-500/20 text-red-400':'bg-yellow-500/20 text-yellow-400' ?> font-bold"><?= $p['stock'] ?> left</span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Quick Stats Footer -->
<div class="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
  <?php foreach([['Newsletter Subscribers',$subscribers,'📧'],['Top Products',count($topProducts),'🏆'],['Low Stock Items',count($lowStock),'⚠️'],['Total Revenue '.'₹'.number_format($totalRevenue/1000,1).'K','all time','💰']] as [$l,$v,$i]): ?>
  <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-3 flex items-center gap-3">
    <span class="text-xl"><?= $i ?></span>
    <div><p class="text-white font-bold text-sm"><?= is_numeric($v)?number_format((int)$v):$v ?></p><p class="text-gray-500 text-xs"><?= $l ?></p></div>
  </div>
  <?php endforeach; ?>
</div>

<script>
const revenueData = <?= json_encode($revenueByMonth) ?>;
const catData = <?= json_encode($salesByCat) ?>;

new Chart(document.getElementById('revenueChart'), {
  type:'line',
  data:{ labels:revenueData.map(r=>r.month), datasets:[{label:'Revenue (₹)',data:revenueData.map(r=>parseFloat(r.revenue)||0),borderColor:'hsl(217,91%,62%)',backgroundColor:'hsla(217,91%,62%,0.1)',tension:.4,fill:true,pointBackgroundColor:'hsl(217,91%,62%)'}]},
  options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8',font:{size:11}}},y:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8',font:{size:11},callback:v=>'₹'+v.toLocaleString('en-IN')}}}}
});

new Chart(document.getElementById('catChart'), {
  type:'doughnut',
  data:{ labels:catData.map(c=>c.name), datasets:[{data:catData.map(c=>parseFloat(c.total)||0),backgroundColor:['#3b82f6','#06b6d4','#8b5cf6','#f59e0b','#22c55e','#ef4444','#ec4899','#f97316'],borderWidth:0,hoverOffset:4}]},
  options:{responsive:true,plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',font:{size:10},boxWidth:10,padding:8}}}}
});
</script>
