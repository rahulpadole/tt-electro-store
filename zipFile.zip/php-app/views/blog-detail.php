<?php
$bm = new BlogModel();
$blog = $bm->findBySlug($blogSlug);
if(!$blog){ http_response_code(404); include __DIR__.'/not-found.php'; return; }
$bm->incrementViews((int)$blog['id']);
$pageTitle = $blog['title'];
$pageDesc  = $blog['excerpt']??$blog['title'];
$related = $bm->all(1,3,$blog['category']??'');
$related['items'] = array_filter($related['items'],fn($r)=>$r['id']!=$blog['id']);
?>
<div class="max-w-3xl mx-auto px-4 py-8">
  <nav class="flex items-center gap-2 text-sm text-gray-500 mb-6">
    <a href="/" class="hover:text-gray-300">Home</a><span>/</span>
    <a href="/blogs" class="hover:text-gray-300">Blog</a><span>/</span>
    <span class="text-gray-300 truncate"><?= clean($blog['title']) ?></span>
  </nav>

  <?php if($blog['thumbnail']): ?>
  <img src="<?= clean($blog['thumbnail']) ?>" alt="<?= clean($blog['title']) ?>" class="w-full h-72 object-cover rounded-2xl mb-8">
  <?php endif; ?>

  <div class="mb-6">
    <?php if($blog['category']): ?><span class="text-xs font-bold text-blue-400 uppercase tracking-wider"><?= clean($blog['category']) ?></span><?php endif; ?>
    <h1 class="text-3xl font-bold text-white mt-2 leading-tight"><?= clean($blog['title']) ?></h1>
    <div class="flex items-center gap-4 mt-4 text-sm text-gray-500">
      <span>by <span class="text-gray-300"><?= clean($blog['author_name']??'TT Electro') ?></span></span>
      <span>·</span>
      <span><?= date('F j, Y',strtotime($blog['created_at'])) ?></span>
      <?php if($blog['reading_time']): ?><span>·</span><span>⏱ <?= $blog['reading_time'] ?> min read</span><?php endif; ?>
      <span>·</span><span>👁 <?= number_format($blog['view_count']) ?> views</span>
    </div>
  </div>

  <?php if($blog['excerpt']): ?>
  <p class="text-lg text-gray-300 border-l-4 border-blue-500 pl-4 mb-6 italic leading-relaxed"><?= clean($blog['excerpt']) ?></p>
  <?php endif; ?>

  <div class="prose prose-invert prose-sm max-w-none text-gray-300 leading-relaxed">
    <?= nl2br(clean($blog['content'])) ?>
  </div>

  <?php if(!empty($blog['tags'])): ?>
  <div class="flex flex-wrap gap-2 mt-8 pt-6 border-t border-white/10">
    <?php foreach((array)$blog['tags'] as $tag): ?>
    <a href="/blogs?tag=<?= urlencode($tag) ?>" class="px-3 py-1 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white text-sm transition-colors">#<?= clean($tag) ?></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Share -->
  <div class="mt-8 p-5 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5">
    <p class="text-sm text-gray-400 mb-3 font-medium">Share this article</p>
    <div class="flex gap-3">
      <?php $shareUrl = urlencode("https://".$_SERVER['HTTP_HOST']."/blogs/{$blog['slug']}"); $shareTitle = urlencode($blog['title']); ?>
      <a href="https://twitter.com/intent/tweet?text=<?= $shareTitle ?>&url=<?= $shareUrl ?>" target="_blank" class="px-4 py-2 rounded-lg bg-sky-500/20 text-sky-400 hover:bg-sky-500/30 text-sm font-medium transition-colors">Twitter</a>
      <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= $shareUrl ?>" target="_blank" class="px-4 py-2 rounded-lg bg-blue-700/20 text-blue-400 hover:bg-blue-700/30 text-sm font-medium transition-colors">LinkedIn</a>
      <a href="https://wa.me/?text=<?= $shareTitle ?>%20<?= $shareUrl ?>" target="_blank" class="px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 text-sm font-medium transition-colors">WhatsApp</a>
    </div>
  </div>
</div>

<!-- Related Posts -->
<?php if(!empty($related['items'])): ?>
<div class="max-w-7xl mx-auto px-4 pb-12">
  <h2 class="text-xl font-bold text-white mb-6">Related Articles</h2>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
    <?php foreach(array_slice($related['items'],0,3) as $b): ?>
    <a href="/blogs/<?= clean($b['slug']) ?>" class="group block rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 overflow-hidden transition-all hover:-translate-y-1">
      <?php if($b['thumbnail']): ?><div class="h-36 overflow-hidden"><img src="<?= clean($b['thumbnail']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"></div><?php else: ?><div class="h-36 bg-gradient-to-br from-blue-900/20 to-cyan-900/20 flex items-center justify-center text-4xl">📝</div><?php endif; ?>
      <div class="p-4"><h3 class="font-semibold text-white group-hover:text-blue-400 transition-colors line-clamp-2 text-sm"><?= clean($b['title']) ?></h3></div>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
