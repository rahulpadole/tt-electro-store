<?php
$pageTitle = 'Blog';
$bm = new BlogModel();
$page = max(1,(int)($_GET['page']??1));
$category = $_GET['category']??'';
$result = $bm->all($page,9,$category);
?>
<div class="max-w-7xl mx-auto px-4 py-8">
  <div class="text-center mb-10">
    <h1 class="text-3xl font-bold text-white mb-2">Tech Blog</h1>
    <p class="text-gray-400">Tips, tutorials, project ideas and maker stories</p>
  </div>

  <?php if(empty($result['items'])): ?>
  <div class="text-center py-20">
    <div class="text-6xl mb-4">📝</div>
    <p class="text-gray-400 text-lg">No blog posts yet. Check back soon!</p>
  </div>
  <?php else: ?>
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php foreach($result['items'] as $b): ?>
    <a href="/blogs/<?= clean($b['slug']) ?>" class="group block rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 overflow-hidden transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-500/5">
      <?php if($b['thumbnail']): ?>
      <div class="h-48 overflow-hidden"><img src="<?= clean($b['thumbnail']) ?>" alt="<?= clean($b['title']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"></div>
      <?php else: ?><div class="h-48 bg-gradient-to-br from-blue-900/30 to-cyan-900/30 flex items-center justify-center text-6xl">📝</div><?php endif; ?>
      <div class="p-5">
        <?php if($b['category']): ?><span class="text-xs font-semibold text-blue-400 uppercase tracking-wide"><?= clean($b['category']) ?></span><?php endif; ?>
        <h2 class="font-bold text-white group-hover:text-blue-400 mt-1.5 transition-colors line-clamp-2 text-lg leading-tight"><?= clean($b['title']) ?></h2>
        <p class="text-gray-400 text-sm mt-2 line-clamp-3 leading-relaxed"><?= clean($b['excerpt']??'') ?></p>
        <div class="flex items-center justify-between mt-4 text-xs text-gray-500">
          <span>by <?= clean($b['author_name']??'TT Electro') ?></span>
          <div class="flex items-center gap-3">
            <?php if($b['reading_time']): ?><span>⏱ <?= $b['reading_time'] ?> min read</span><?php endif; ?>
            <span><?= date('M j',strtotime($b['created_at'])) ?></span>
          </div>
        </div>
        <?php if(!empty($b['tags'])): ?>
        <div class="flex flex-wrap gap-1 mt-3">
          <?php foreach(array_slice((array)$b['tags'],0,3) as $tag): ?>
          <span class="px-2 py-0.5 rounded-full bg-white/5 text-gray-500 text-xs">#<?= clean($tag) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </a>
    <?php endforeach; ?>
  </div>

  <?php if($result['total_pages']>1): ?>
  <div class="flex items-center justify-center gap-2 mt-10">
    <?php if($page>1): ?><a href="?page=<?= $page-1 ?><?= $category?"&category={$category}":'' ?>" class="px-4 py-2 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white text-sm">‹ Prev</a><?php endif; ?>
    <?php for($i=1;$i<=$result['total_pages'];$i++): ?>
    <a href="?page=<?= $i ?><?= $category?"&category={$category}":'' ?>" class="px-3 py-2 rounded-lg text-sm <?= $i===$page?'bg-blue-600 text-white':'bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if($page<$result['total_pages']): ?><a href="?page=<?= $page+1 ?><?= $category?"&category={$category}":'' ?>" class="px-4 py-2 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white text-sm">Next ›</a><?php endif; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
