<?php
$pageTitle = 'Shopping Cart';
$cartModel = new CartModel();
$items = $cartModel->getItems(getCurrentUserId());

$subtotal = array_sum(array_map(fn($i) => (float)(($i['is_flash_sale']&&$i['flash_sale_price'])?$i['flash_sale_price']:$i['price']) * (int)$i['quantity'], $items));
?>
<div class="max-w-7xl mx-auto px-4 py-8" x-data="cartPage()">
  <h1 class="text-2xl font-bold text-white mb-8">Shopping Cart <span class="text-gray-500 text-lg font-normal">(<?= count($items) ?> items)</span></h1>

  <?php if(empty($items)): ?>
  <div class="text-center py-24">
    <div class="text-7xl mb-4">🛒</div>
    <p class="text-xl text-gray-400 font-medium mb-2">Your cart is empty</p>
    <p class="text-gray-500 text-sm mb-6">Add some awesome electronics to get started!</p>
    <a href="/products" class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">Browse Products →</a>
  </div>
  <?php else: ?>
  <div class="flex flex-col lg:flex-row gap-8">
    <!-- Cart Items -->
    <div class="flex-1 space-y-4">
      <?php foreach($items as $item):
        $price = (float)(($item['is_flash_sale']&&$item['flash_sale_price'])?$item['flash_sale_price']:$item['price']);
      ?>
      <div class="flex items-center gap-4 p-4 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5" id="cart-item-<?= $item['id'] ?>">
        <a href="/products/<?= $item['product_id'] ?>" class="flex-shrink-0">
          <?php if($item['thumbnail']): ?>
          <img src="<?= clean($item['thumbnail']) ?>" alt="<?= clean($item['name']) ?>" class="w-20 h-20 rounded-xl object-cover">
          <?php else: ?>
          <div class="w-20 h-20 rounded-xl bg-[hsl(222,47%,15%)] flex items-center justify-center text-3xl">📦</div>
          <?php endif; ?>
        </a>
        <div class="flex-1 min-w-0">
          <a href="/products/<?= $item['product_id'] ?>" class="font-medium text-white hover:text-blue-400 text-sm line-clamp-2"><?= clean($item['name']) ?></a>
          <p class="text-blue-400 font-bold mt-1">₹<?= number_format($price,2) ?></p>
          <?php if($item['is_flash_sale']&&$item['flash_sale_price']): ?>
          <span class="text-xs text-red-400">⚡ Flash sale price</span>
          <?php endif; ?>
        </div>
        <div class="flex items-center gap-2 bg-[hsl(222,47%,13%)] border border-white/10 rounded-xl px-1">
          <button onclick="updateQty(<?= $item['id'] ?>, <?= max(1,(int)$item['quantity']-1) ?>)" class="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-white">−</button>
          <span id="qty-<?= $item['id'] ?>" class="w-5 text-center text-white text-sm font-medium"><?= $item['quantity'] ?></span>
          <button onclick="updateQty(<?= $item['id'] ?>, <?= (int)$item['quantity']+1 ?>)" class="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-white">+</button>
        </div>
        <div class="text-right min-w-[80px]">
          <p class="font-bold text-white">₹<?= number_format($price*(int)$item['quantity'],2) ?></p>
          <button onclick="removeItem(<?= $item['id'] ?>)" class="text-xs text-red-400 hover:text-red-300 mt-1 transition-colors">Remove</button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Order Summary -->
    <div class="lg:w-80 flex-shrink-0">
      <div class="sticky top-20 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-5 space-y-4">
        <h2 class="font-bold text-white text-lg">Order Summary</h2>

        <!-- Coupon -->
        <div>
          <p class="text-sm text-gray-400 mb-2">Have a coupon code?</p>
          <div class="flex gap-2">
            <input type="text" x-model="couponCode" placeholder="Enter code" class="flex-1 px-3 py-2 rounded-lg bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 uppercase">
            <button @click="applyCoupon()" :disabled="couponLoading" class="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm transition-colors disabled:opacity-50">Apply</button>
          </div>
          <p x-show="couponMsg" x-text="couponMsg" :class="couponValid?'text-green-400':'text-red-400'" class="text-xs mt-1.5"></p>
        </div>

        <div class="space-y-2 border-t border-white/10 pt-3">
          <div class="flex justify-between text-sm text-gray-400">
            <span>Subtotal</span>
            <span x-text="'₹'+subtotal.toLocaleString('en-IN',{minimumFractionDigits:2})"></span>
          </div>
          <div x-show="discount>0" class="flex justify-between text-sm text-green-400">
            <span>Coupon Discount</span>
            <span>-₹<span x-text="discount.toFixed(2)"></span></span>
          </div>
          <div class="flex justify-between text-sm text-gray-400">
            <span>Shipping</span>
            <span x-text="shipping===0?'FREE':'₹'+shipping"></span>
          </div>
          <div class="flex justify-between font-bold text-white text-base border-t border-white/10 pt-2 mt-2">
            <span>Total</span>
            <span>₹<span x-text="(subtotal-discount+shipping).toLocaleString('en-IN',{minimumFractionDigits:2})"></span></span>
          </div>
        </div>

        <a href="/checkout" class="block w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-center transition-all hover:scale-[1.02]">
          Proceed to Checkout →
        </a>
        <a href="/products" class="block w-full py-2 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400 text-sm text-center transition-all">Continue Shopping</a>

        <!-- Accepted payments -->
        <div class="flex items-center gap-2 pt-2 border-t border-white/10">
          <span class="text-xs text-gray-500">Accepts:</span>
          <div class="flex gap-1.5 flex-wrap">
            <?php foreach(['COD','UPI','Card','NetBanking'] as $pm): ?>
            <span class="px-1.5 py-0.5 rounded bg-white/10 text-gray-400 text-xs"><?= $pm ?></span>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
function cartPage() {
  return {
    subtotal: <?= $subtotal ?>,
    discount: 0,
    shipping: <?= $subtotal >= 499 ? 0 : 49 ?>,
    couponCode: '',
    couponMsg: '',
    couponValid: false,
    couponLoading: false,
    async applyCoupon() {
      if(!this.couponCode.trim()) return;
      this.couponLoading = true;
      try {
        const d = await apiFetch('/api/coupons/validate', { method: 'POST', body: JSON.stringify({ code: this.couponCode, order_amount: this.subtotal }) });
        this.discount = d.data.discount;
        this.couponMsg = `Coupon applied! You save ₹${d.data.discount.toFixed(2)}`;
        this.couponValid = true;
        showToast('Coupon applied!', 'success');
      } catch(e) { this.couponMsg = e.message; this.couponValid = false; }
      this.couponLoading = false;
    }
  }
}

async function updateQty(itemId, qty) {
  if(qty < 1) { removeItem(itemId); return; }
  try {
    await apiFetch(`/api/cart/${itemId}`, { method: 'PATCH', body: JSON.stringify({ quantity: qty }) });
    document.getElementById(`qty-${itemId}`).textContent = qty;
  } catch(e) { showToast(e.message, 'error'); }
}

async function removeItem(itemId) {
  try {
    await apiFetch(`/api/cart/${itemId}`, { method: 'DELETE' });
    document.getElementById(`cart-item-${itemId}`)?.remove();
    showToast('Removed from cart', 'success');
  } catch(e) { showToast(e.message, 'error'); }
}
</script>
