<?php
$pageTitle = 'Checkout';
$cartModel = new CartModel();
$items = $cartModel->getItems(getCurrentUserId());
if(empty($items)) { redirect('/cart'); }
$subtotal = array_sum(array_map(fn($i) => (float)(($i['is_flash_sale']&&$i['flash_sale_price'])?$i['flash_sale_price']:$i['price']) * (int)$i['quantity'], $items));
$shipping = $subtotal >= 499 ? 0 : 49;
$user = getCurrentUser();
?>
<div class="max-w-5xl mx-auto px-4 py-8" x-data="checkoutPage()">
  <h1 class="text-2xl font-bold text-white mb-8">Checkout</h1>

  <!-- Steps indicator -->
  <div class="flex items-center gap-2 mb-8">
    <?php foreach(['Shipping','Payment','Confirm'] as $si => $step): ?>
    <div class="flex items-center gap-2">
      <div class="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold" :class="step >= <?= $si+1 ?> ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-400'"><?= $si+1 ?></div>
      <span class="text-sm" :class="step >= <?= $si+1 ?> ? 'text-white font-medium' : 'text-gray-500'"><?= $step ?></span>
    </div>
    <?php if($si < 2): ?><div class="flex-1 h-px bg-white/10 mx-2"></div><?php endif; ?>
    <?php endforeach; ?>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2 space-y-5">

      <!-- Step 1: Shipping -->
      <div x-show="step===1" class="space-y-4">
        <h2 class="text-lg font-semibold text-white">Shipping Address</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Full Name *</label>
            <input type="text" x-model="form.name" :value="'<?= clean($user['name']??'') ?>'" placeholder="Your full name"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Phone *</label>
            <input type="tel" x-model="form.phone" :value="'<?= clean($user['phone']??'') ?>'" placeholder="+91 98765 43210"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div class="sm:col-span-2">
            <label class="text-xs text-gray-400 mb-1 block">Address Line 1 *</label>
            <input type="text" x-model="form.address1" placeholder="House/Flat no., Street"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div class="sm:col-span-2">
            <label class="text-xs text-gray-400 mb-1 block">Address Line 2</label>
            <input type="text" x-model="form.address2" placeholder="Area, Landmark (optional)"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">City *</label>
            <input type="text" x-model="form.city" placeholder="Mumbai"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">State *</label>
            <input type="text" x-model="form.state" placeholder="Maharashtra"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">PIN Code *</label>
            <input type="text" x-model="form.pincode" placeholder="400001"
                   class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="text-xs text-gray-400 mb-1 block">Country</label>
            <input type="text" value="India" readonly class="w-full px-3 py-2.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-gray-400 text-sm">
          </div>
        </div>
        <button @click="nextStep()" class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">Continue to Payment →</button>
      </div>

      <!-- Step 2: Payment -->
      <div x-show="step===2" class="space-y-4">
        <h2 class="text-lg font-semibold text-white">Payment Method</h2>
        <div class="space-y-3">
          <?php foreach([['cod','💵','Cash on Delivery','Pay when your order arrives'],['upi','📱','UPI / QR','Google Pay, PhonePe, BHIM'],['card','💳','Credit / Debit Card','Visa, Mastercard, RuPay'],['netbanking','🏦','Net Banking','All major banks supported']] as [$val,$icon,$label,$sub]): ?>
          <label class="flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all" :class="paymentMethod==='<?= $val ?>' ? 'border-blue-500 bg-blue-500/10' : 'border-white/10 bg-[hsl(222,47%,10%)] hover:border-white/20'">
            <input type="radio" x-model="paymentMethod" value="<?= $val ?>" class="accent-blue-500">
            <span class="text-2xl"><?= $icon ?></span>
            <div>
              <p class="font-medium text-white text-sm"><?= $label ?></p>
              <p class="text-gray-400 text-xs"><?= $sub ?></p>
            </div>
          </label>
          <?php endforeach; ?>
        </div>
        <div class="flex gap-3 pt-2">
          <button @click="step=1" class="flex-1 py-3 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400 font-medium transition-all">← Back</button>
          <button @click="nextStep()" class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">Review Order →</button>
        </div>
      </div>

      <!-- Step 3: Confirm -->
      <div x-show="step===3" class="space-y-4">
        <h2 class="text-lg font-semibold text-white">Review Your Order</h2>
        <div class="p-4 rounded-xl bg-[hsl(222,47%,10%)] border border-white/10 space-y-2">
          <div class="flex justify-between text-sm"><span class="text-gray-400">Name</span><span class="text-gray-200" x-text="form.name"></span></div>
          <div class="flex justify-between text-sm"><span class="text-gray-400">Phone</span><span class="text-gray-200" x-text="form.phone"></span></div>
          <div class="flex justify-between text-sm"><span class="text-gray-400">Address</span><span class="text-gray-200 text-right max-w-xs" x-text="`${form.address1}, ${form.city}, ${form.state} - ${form.pincode}`"></span></div>
          <div class="flex justify-between text-sm"><span class="text-gray-400">Payment</span><span class="text-gray-200 capitalize" x-text="paymentMethod"></span></div>
        </div>
        <div class="flex gap-3">
          <button @click="step=2" class="flex-1 py-3 rounded-xl border border-white/10 hover:bg-white/5 text-gray-400 font-medium transition-all">← Back</button>
          <button @click="placeOrder()" :disabled="loading" class="flex-1 py-3 rounded-xl bg-green-600 hover:bg-green-500 text-white font-semibold transition-all disabled:opacity-50">
            <span x-show="!loading">✓ Place Order</span>
            <span x-show="loading">Placing Order...</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Order Summary Sidebar -->
    <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-5 h-fit sticky top-20">
      <h3 class="font-semibold text-white mb-4">Order Items (<?= count($items) ?>)</h3>
      <div class="space-y-3 max-h-64 overflow-y-auto mb-4">
        <?php foreach($items as $item):
          $p = (float)(($item['is_flash_sale']&&$item['flash_sale_price'])?$item['flash_sale_price']:$item['price']);
        ?>
        <div class="flex items-center gap-3">
          <?php if($item['thumbnail']): ?>
          <img src="<?= clean($item['thumbnail']) ?>" class="w-10 h-10 rounded-lg object-cover flex-shrink-0">
          <?php else: ?><div class="w-10 h-10 rounded-lg bg-[hsl(222,47%,15%)] flex items-center justify-center text-xl flex-shrink-0">📦</div><?php endif; ?>
          <div class="flex-1 min-w-0">
            <p class="text-xs text-gray-300 line-clamp-1"><?= clean($item['name']) ?></p>
            <p class="text-xs text-gray-500">×<?= $item['quantity'] ?></p>
          </div>
          <span class="text-sm font-medium text-white">₹<?= number_format($p*(int)$item['quantity'],2) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="space-y-2 border-t border-white/10 pt-3 text-sm">
        <div class="flex justify-between text-gray-400"><span>Subtotal</span><span>₹<?= number_format($subtotal,2) ?></span></div>
        <div class="flex justify-between text-gray-400"><span>Shipping</span><span><?= $shipping===0?'FREE':'₹'.$shipping ?></span></div>
        <div class="flex justify-between font-bold text-white text-base pt-1 border-t border-white/10">
          <span>Total</span><span>₹<?= number_format($subtotal+$shipping,2) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function checkoutPage() {
  return {
    step: 1, loading: false, paymentMethod: 'cod',
    form: { name: '<?= clean($user['name']??'') ?>', phone: '<?= clean($user['phone']??'') ?>', address1:'', address2:'', city:'', state:'', pincode:'' },
    nextStep() {
      if(this.step===1) {
        if(!this.form.name||!this.form.phone||!this.form.address1||!this.form.city||!this.form.state||!this.form.pincode)
        { showToast('Please fill all required fields','error'); return; }
      }
      this.step++;
    },
    async placeOrder() {
      this.loading = true;
      const addr = { name:this.form.name, phone:this.form.phone, address_line1:this.form.address1, address_line2:this.form.address2, city:this.form.city, state:this.form.state, pincode:this.form.pincode, country:'India' };
      const items = <?= json_encode(array_map(fn($i)=>['product_id'=>$i['product_id'],'product_name'=>$i['name'],'thumbnail'=>$i['thumbnail'],'quantity'=>(int)$i['quantity'],'price'=>(float)(($i['is_flash_sale']&&$i['flash_sale_price'])?$i['flash_sale_price']:$i['price'])],$items)) ?>;
      const subtotal = <?= $subtotal ?>; const shipping = <?= $shipping ?>;
      try {
        const d = await apiFetch('/api/orders', { method:'POST', body:JSON.stringify({ items, shipping_address:addr, payment_method:this.paymentMethod, subtotal, shipping, total:subtotal+shipping }) });
        showToast('Order placed successfully!','success');
        setTimeout(()=>location.href='/orders/'+d.data.id, 1000);
      } catch(e) { showToast(e.message,'error'); }
      this.loading = false;
    }
  }
}
</script>
