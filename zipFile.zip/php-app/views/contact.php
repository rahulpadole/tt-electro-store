<?php $pageTitle = 'Contact Us'; ?>
<div class="max-w-5xl mx-auto px-4 py-8">
  <div class="text-center mb-10">
    <h1 class="text-3xl font-bold text-white mb-2">Contact Us</h1>
    <p class="text-gray-400">We're here to help! Reach out for support, partnerships, or feedback.</p>
  </div>
  <div class="grid grid-cols-1 lg:grid-cols-5 gap-8">
    <div class="lg:col-span-3 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-6" x-data="contactForm()">
      <h2 class="font-bold text-white text-lg mb-5">Send a Message</h2>
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-4">
          <div><label class="text-xs text-gray-400 mb-1 block">Your Name *</label>
          <input type="text" x-model="form.name" placeholder="John Doe" class="w-full px-3 py-2.5 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
          <div><label class="text-xs text-gray-400 mb-1 block">Email *</label>
          <input type="email" x-model="form.email" placeholder="you@email.com" class="w-full px-3 py-2.5 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
        </div>
        <div><label class="text-xs text-gray-400 mb-1 block">Phone</label>
        <input type="tel" x-model="form.phone" placeholder="+91 98765 43210" class="w-full px-3 py-2.5 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
        <div><label class="text-xs text-gray-400 mb-1 block">Subject</label>
        <select x-model="form.subject" class="w-full px-3 py-2.5 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-gray-300 text-sm focus:outline-none focus:border-blue-500">
          <option value="">Select subject</option>
          <?php foreach(['Order Support','Product Inquiry','3D Printing','Partnership','Feedback','Other'] as $s): ?><option value="<?= $s ?>"><?= $s ?></option><?php endforeach; ?>
        </select></div>
        <div><label class="text-xs text-gray-400 mb-1 block">Message *</label>
        <textarea x-model="form.message" rows="4" placeholder="Tell us how we can help..." class="w-full px-3 py-2.5 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 resize-none"></textarea></div>
        <p x-show="success" class="text-green-400 text-sm bg-green-500/10 px-3 py-2 rounded-lg border border-green-500/20">✓ Message sent! We'll get back to you within 24 hours.</p>
        <p x-show="error" x-text="error" class="text-red-400 text-sm bg-red-500/10 px-3 py-2 rounded-lg border border-red-500/20"></p>
        <button @click="submit()" :disabled="loading||success" class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all disabled:opacity-50">
          <span x-show="!loading&&!success">Send Message →</span>
          <span x-show="loading">Sending...</span>
          <span x-show="success">✓ Sent!</span>
        </button>
      </div>
    </div>
    <div class="lg:col-span-2 space-y-4">
      <?php foreach([['📍','Our Address','123 Maker Street, Tech Park\nBangalore, Karnataka 560001'],['📞','Phone','+91 98765 43210\nMon–Sat, 9am–6pm IST'],['✉️','Email','support@ttelectro.in\nbusiness@ttelectro.in'],['💬','WhatsApp','Chat with us on WhatsApp\nFor quick support']] as [$icon,$title,$info]): ?>
      <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-4 flex items-start gap-3">
        <span class="text-2xl"><?= $icon ?></span>
        <div><p class="font-semibold text-white text-sm"><?= $title ?></p><p class="text-gray-400 text-sm mt-0.5 whitespace-pre-line"><?= $info ?></p></div>
      </div>
      <?php endforeach; ?>
      <div class="rounded-xl bg-gradient-to-br from-green-900/30 to-[hsl(222,47%,12%)] border border-green-500/20 p-4">
        <p class="font-semibold text-white text-sm mb-2">Quick WhatsApp Support</p>
        <a href="https://wa.me/919876543210" target="_blank" class="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-green-500 hover:bg-green-400 text-white font-medium text-sm transition-colors justify-center">
          💬 Chat on WhatsApp
        </a>
      </div>
    </div>
  </div>
</div>
<script>
function contactForm(){return{form:{name:'',email:'',phone:'',subject:'',message:''},loading:false,error:'',success:false,async submit(){if(!this.form.name||!this.form.email||!this.form.message){this.error='Please fill required fields';return;}this.loading=true;this.error='';try{await apiFetch('/api/contact',{method:'POST',body:JSON.stringify(this.form)});this.success=true;this.form={name:'',email:'',phone:'',subject:'',message:''};}catch(e){this.error=e.message;}this.loading=false;}}}
</script>
