<?php
$pageTitle = 'Dashboard';
$user = getCurrentUser();
$om = new OrderModel();
$wm = new WishlistModel();
$nm = new NotificationModel();
$orders = $om->getForUser((int)$user['id']);
$wishlistCount = $wm->count((int)$user['id']);
$unread = $nm->unreadCount((int)$user['id']);
$recentOrders = array_slice($orders, 0, 3);
$statusColors = ['pending'=>'yellow','processing'=>'blue','shipped'=>'purple','delivered'=>'green','cancelled'=>'red'];
?>
<div class="max-w-4xl mx-auto px-4 py-8">
  <div class="flex items-center gap-4 mb-8">
    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white font-bold text-xl">
      <?= strtoupper(substr($user['name'],0,1)) ?>
    </div>
    <div>
      <h1 class="text-2xl font-bold text-white">Hello, <?= clean(explode(' ',$user['name'])[0]) ?>! 👋</h1>
      <p class="text-gray-400 text-sm"><?= clean($user['email']) ?></p>
    </div>
  </div>

  <!-- Stats -->
  <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <?php foreach([[count($orders),'Total Orders','📦','blue'],[array_sum(array_map(fn($o)=>(float)$o['total'],$orders)),'Total Spent','₹','green'],[$wishlistCount,'Wishlist Items','❤️','pink'],[$user['loyalty_points']??0,'Loyalty Points','⭐','yellow']] as [$val,$label,$icon,$color]): ?>
    <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 p-4 text-center">
      <div class="text-2xl mb-1"><?= $icon ?></div>
      <p class="text-xl font-bold text-white"><?= is_float($val) ? '₹'.number_format($val,0) : number_format((int)$val) ?></p>
      <p class="text-gray-400 text-xs mt-0.5"><?= $label ?></p>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Quick Links -->
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
    <?php foreach([['/orders','📦','My Orders'],[ '/wishlist','❤️','Wishlist'],['/notifications','🔔','Notifications'],['/track-order','🚚','Track Order']] as [$href,$icon,$label]): ?>
    <a href="<?= $href ?>" class="flex flex-col items-center gap-2 p-4 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 hover:bg-[hsl(222,47%,13%)] transition-all group">
      <span class="text-2xl group-hover:scale-110 transition-transform"><?= $icon ?></span>
      <span class="text-sm text-gray-300 group-hover:text-white font-medium transition-colors"><?= $label ?></span>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- Recent Orders -->
  <div>
    <div class="flex items-center justify-between mb-4">
      <h2 class="text-lg font-bold text-white">Recent Orders</h2>
      <a href="/orders" class="text-blue-400 hover:text-blue-300 text-sm">View All →</a>
    </div>
    <?php if(empty($recentOrders)): ?>
    <div class="text-center py-12 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5">
      <div class="text-5xl mb-3">📦</div>
      <p class="text-gray-400">No orders yet. <a href="/products" class="text-blue-400">Start shopping!</a></p>
    </div>
    <?php else: ?>
    <div class="space-y-3">
      <?php foreach($recentOrders as $order):
        $sc = $statusColors[$order['status']] ?? 'gray';
      ?>
      <a href="/orders/<?= $order['id'] ?>" class="flex items-center justify-between p-4 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 transition-all">
        <div>
          <p class="text-white font-medium text-sm"><?= clean($order['order_number']) ?></p>
          <p class="text-gray-500 text-xs mt-0.5"><?= date('M j, Y',strtotime($order['created_at'])) ?></p>
        </div>
        <div class="flex items-center gap-3">
          <span class="px-2 py-0.5 rounded-full text-xs bg-<?= $sc ?>-500/20 text-<?= $sc ?>-400 capitalize"><?= clean($order['status']) ?></span>
          <span class="text-white font-bold text-sm">₹<?= number_format((float)$order['total'],2) ?></span>
          <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
