<?php
$pageTitle = 'FAQ';
$faqs = (new FaqModel())->all();
$grouped = [];
foreach($faqs as $f) { $grouped[$f['category']??'General'][] = $f; }
?>
<div class="max-w-3xl mx-auto px-4 py-8">
  <div class="text-center mb-10">
    <h1 class="text-3xl font-bold text-white mb-2">Frequently Asked Questions</h1>
    <p class="text-gray-400">Find answers to common questions about orders, products, and services</p>
  </div>
  <?php if(empty($faqs)): ?>
  <div class="text-center py-16"><div class="text-5xl mb-4">❓</div><p class="text-gray-400">No FAQs available yet.</p></div>
  <?php else: ?>
  <?php foreach($grouped as $cat => $items): ?>
  <div class="mb-8">
    <h2 class="text-sm font-bold text-blue-400 uppercase tracking-widest mb-3"><?= clean($cat) ?></h2>
    <div class="space-y-2">
      <?php foreach($items as $f): ?>
      <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5" x-data="{open:false}">
        <button @click="open=!open" class="w-full flex items-center justify-between px-5 py-4 text-left">
          <span class="font-medium text-gray-200 text-sm pr-4"><?= clean($f['question']) ?></span>
          <svg class="w-4 h-4 text-gray-400 flex-shrink-0 transition-transform" :class="open&&'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div x-show="open" x-transition class="px-5 pb-4 text-sm text-gray-400 leading-relaxed border-t border-white/5 pt-3"><?= nl2br(clean($f['answer'])) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>

  <div class="mt-10 p-6 rounded-2xl bg-gradient-to-r from-blue-900/30 to-[hsl(222,47%,12%)] border border-blue-500/20 text-center">
    <p class="text-white font-semibold mb-1">Still have questions?</p>
    <p class="text-gray-400 text-sm mb-4">Our support team is ready to help you</p>
    <a href="/contact" class="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm transition-all">Contact Support →</a>
  </div>
</div>
