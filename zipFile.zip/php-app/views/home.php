<?php
$pageTitle = 'Premium Electronics for Makers';
$pageDesc  = 'TT Electro Store – Premium electronics, DIY kits, and 3D printing for makers and engineers in India.';
$banners   = (new BannerModel())->active();
$categories= (new CategoryModel())->all();
$featured  = (new ProductModel())->featured(8);
$trending  = (new ProductModel())->trending(8);
$bestSellers=(new ProductModel())->bestSellers(8);
$flashSale = (new ProductModel())->flashSale(6);
$diyKits   = (new DiyKitModel())->all();
$blogs     = (new BlogModel())->all(1,3);
$faqs      = (new FaqModel())->all();
$offers    = (new OfferModel())->active();
?>

<!-- Hero Slider -->
<section class="relative overflow-hidden bg-[hsl(222,47%,8%)]" x-data="heroSlider()">
  <div class="relative h-[480px] md:h-[580px]">
    <?php foreach($banners as $i => $banner): ?>
    <div class="absolute inset-0 transition-opacity duration-700"
         :class="current === <?= $i ?> ? 'opacity-100 z-10' : 'opacity-0 z-0'">
      <?php if($banner['image']): ?>
      <img src="<?= clean($banner['image']) ?>" alt="<?= clean($banner['title']) ?>"
           class="w-full h-full object-cover">
      <div class="absolute inset-0 bg-gradient-to-r from-[hsl(222,47%,6%)]/90 via-[hsl(222,47%,6%)]/50 to-transparent"></div>
      <?php else: ?>
      <div class="w-full h-full bg-gradient-to-br from-blue-900 via-[hsl(222,47%,10%)] to-cyan-900"></div>
      <?php endif; ?>

      <div class="absolute inset-0 flex items-center">
        <div class="max-w-7xl mx-auto px-4 md:px-8 w-full">
          <div class="max-w-xl fade-in">
            <?php if($banner['badge']): ?>
            <span class="inline-block px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-semibold mb-4 border border-cyan-500/30">
              <?= clean($banner['badge']) ?>
            </span>
            <?php endif; ?>
            <h1 class="text-3xl md:text-5xl font-bold text-white leading-tight mb-4">
              <?= clean($banner['title']) ?>
            </h1>
            <?php if($banner['subtitle']): ?>
            <p class="text-gray-300 text-lg mb-8"><?= clean($banner['subtitle']) ?></p>
            <?php endif; ?>
            <div class="flex gap-3 flex-wrap">
              <a href="<?= clean($banner['link'] ?? '/products') ?>"
                 class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all hover:scale-105 shadow-lg shadow-blue-500/20">
                Shop Now →
              </a>
              <a href="/3d-printing"
                 class="px-6 py-3 rounded-xl border border-white/20 hover:bg-white/10 text-white font-semibold transition-all">
                3D Printing
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>

    <?php if(empty($banners)): ?>
    <div class="w-full h-full bg-gradient-to-br from-blue-900 via-[hsl(222,47%,10%)] to-cyan-900 flex items-center">
      <div class="max-w-7xl mx-auto px-4 w-full">
        <div class="max-w-xl">
          <span class="inline-block px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-400 text-xs font-semibold mb-4">New Arrivals</span>
          <h1 class="text-4xl md:text-5xl font-bold text-white leading-tight mb-4">Power Your <span class="text-cyan-400">Next Idea</span></h1>
          <p class="text-gray-300 text-lg mb-8">Premium electronics for makers and engineers</p>
          <div class="flex gap-3"><a href="/products" class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">Shop Now →</a></div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Slider controls -->
    <?php if(count($banners) > 1): ?>
    <button @click="prev()" class="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all">‹</button>
    <button @click="next()" class="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all">›</button>
    <div class="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
      <?php foreach($banners as $i => $b): ?>
      <button @click="current=<?= $i ?>" :class="current===<?= $i ?> ? 'bg-blue-500 w-6' : 'bg-white/30 w-2'" class="h-2 rounded-full transition-all"></button>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Trust badges -->
  <div class="border-t border-white/10 bg-[hsl(222,47%,7%)]">
    <div class="max-w-7xl mx-auto px-4 py-4 grid grid-cols-2 md:grid-cols-4 gap-4">
      <?php foreach([['🚚','Fast Delivery','5-7 business days'],['🛡️','Genuine Products','100% authentic'],['⚡','Expert Support','Mon-Sat 9am-6pm'],['↩️','Easy Returns','1-day return policy']] as [$icon,$title,$sub]): ?>
      <div class="flex items-center gap-3">
        <span class="text-2xl"><?= $icon ?></span>
        <div><p class="text-white text-sm font-semibold"><?= $title ?></p><p class="text-gray-400 text-xs"><?= $sub ?></p></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Browse Categories -->
<section class="max-w-7xl mx-auto px-4 py-16">
  <div class="flex items-center justify-between mb-8">
    <div>
      <h2 class="text-2xl font-bold text-white">Browse Categories</h2>
      <p class="text-gray-400 text-sm mt-1">Find components by category</p>
    </div>
    <a href="/products" class="text-blue-400 hover:text-blue-300 text-sm font-medium">View All →</a>
  </div>
  <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
    <?php foreach(array_slice($categories,0,12) as $cat): ?>
    <a href="/products?category_id=<?= $cat['id'] ?>"
       class="group flex flex-col items-center gap-3 p-4 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/30 hover:bg-[hsl(222,47%,13%)] transition-all">
      <div class="w-12 h-12 rounded-xl bg-blue-500/10 group-hover:bg-blue-500/20 flex items-center justify-center text-2xl transition-all">
        <?= $cat['icon'] ? clean($cat['icon']) : '📦' ?>
      </div>
      <span class="text-sm text-gray-300 group-hover:text-white text-center font-medium transition-colors"><?= clean($cat['name']) ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- Flash Sale -->
<?php if(!empty($flashSale)): ?>
<section class="bg-gradient-to-r from-red-900/30 via-[hsl(222,47%,8%)] to-orange-900/30 border-y border-red-500/20 py-12">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex items-center justify-between mb-8">
      <div class="flex items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-2xl">⚡</span>
            <h2 class="text-2xl font-bold text-white">Flash Sale</h2>
            <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-xs font-bold border border-red-500/30">HOT</span>
          </div>
          <p class="text-gray-400 text-sm mt-1">Limited time deals — grab before they're gone!</p>
        </div>
        <!-- Countdown -->
        <div class="flex gap-2 ml-4" x-data="countdown(<?= strtotime('+24 hours') ?>)">
          <?php foreach(['hours','minutes','seconds'] as $unit): ?>
          <div class="bg-[hsl(222,47%,10%)] border border-red-500/20 rounded-xl px-3 py-2 text-center min-w-[50px]">
            <div class="text-xl font-bold text-red-400 font-mono" x-text="<?= $unit ?>"></div>
            <div class="text-xs text-gray-500"><?= strtoupper($unit) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <a href="/offers" class="text-red-400 hover:text-red-300 text-sm font-medium">See All →</a>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      <?php foreach($flashSale as $p): ?>
      <?php include __DIR__ . '/../partials/product-card.php'; ?>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- Featured Products -->
<?php if(!empty($featured)): ?>
<section class="max-w-7xl mx-auto px-4 py-16">
  <div class="flex items-center justify-between mb-8">
    <div><h2 class="text-2xl font-bold text-white">Featured Products</h2><p class="text-gray-400 text-sm mt-1">Hand-picked by our experts</p></div>
    <a href="/products?featured=1" class="text-blue-400 hover:text-blue-300 text-sm">View All →</a>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <?php foreach($featured as $p): include __DIR__ . '/../partials/product-card.php'; endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- Trending Products -->
<?php if(!empty($trending)): ?>
<section class="max-w-7xl mx-auto px-4 pb-16">
  <div class="flex items-center justify-between mb-8">
    <div><h2 class="text-2xl font-bold text-white">🔥 Trending Now</h2><p class="text-gray-400 text-sm mt-1">What makers are buying</p></div>
    <a href="/products?trending=1" class="text-blue-400 hover:text-blue-300 text-sm">View All →</a>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <?php foreach($trending as $p): include __DIR__ . '/../partials/product-card.php'; endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- Best Sellers -->
<?php if(!empty($bestSellers)): ?>
<section class="max-w-7xl mx-auto px-4 pb-16">
  <div class="flex items-center justify-between mb-8">
    <div><h2 class="text-2xl font-bold text-white">⭐ Best Sellers</h2><p class="text-gray-400 text-sm mt-1">Most popular products</p></div>
    <a href="/products" class="text-blue-400 hover:text-blue-300 text-sm">View All →</a>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    <?php foreach($bestSellers as $p): include __DIR__ . '/../partials/product-card.php'; endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- DIY Kits Preview -->
<?php if(!empty($diyKits)): ?>
<section class="bg-gradient-to-r from-purple-900/20 via-[hsl(222,47%,8%)] to-blue-900/20 border-y border-purple-500/10 py-16">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex items-center justify-between mb-8">
      <div>
        <h2 class="text-2xl font-bold text-white">🔧 DIY Vision Kits</h2>
        <p class="text-gray-400 text-sm mt-1">Everything you need to build amazing projects</p>
      </div>
      <a href="/diy-kits" class="text-purple-400 hover:text-purple-300 text-sm">View All Kits →</a>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php foreach(array_slice($diyKits,0,3) as $kit): ?>
      <a href="/diy-kits" class="group block rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-purple-500/30 overflow-hidden transition-all hover:-translate-y-1">
        <?php if($kit['thumbnail']): ?>
        <div class="h-44 overflow-hidden">
          <img src="<?= clean($kit['thumbnail']) ?>" alt="<?= clean($kit['name']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
        </div>
        <?php else: ?>
        <div class="h-44 bg-gradient-to-br from-purple-900/30 to-blue-900/30 flex items-center justify-center text-5xl">🔧</div>
        <?php endif; ?>
        <div class="p-4">
          <div class="flex items-center gap-2 mb-2">
            <span class="px-2 py-0.5 rounded-full text-xs font-medium <?= $kit['difficulty']==='beginner'?'bg-green-500/20 text-green-400':($kit['difficulty']==='advanced'?'bg-red-500/20 text-red-400':'bg-yellow-500/20 text-yellow-400') ?>">
              <?= ucfirst(clean($kit['difficulty']??'beginner')) ?>
            </span>
          </div>
          <h3 class="font-semibold text-white group-hover:text-purple-400 transition-colors"><?= clean($kit['name']) ?></h3>
          <p class="text-gray-400 text-sm mt-1 line-clamp-2"><?= clean($kit['description']??'') ?></p>
          <div class="flex items-center justify-between mt-3">
            <span class="text-lg font-bold text-white">₹<?= number_format((float)$kit['price'],2) ?></span>
            <span class="text-xs text-gray-500"><?= count($kit['components']) ?> components</span>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- 3D Printing CTA -->
<section class="max-w-7xl mx-auto px-4 py-16">
  <div class="rounded-2xl bg-gradient-to-r from-blue-900/40 via-[hsl(222,47%,12%)] to-cyan-900/40 border border-blue-500/20 p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
    <div>
      <div class="text-4xl mb-4">🖨️</div>
      <h2 class="text-2xl md:text-3xl font-bold text-white mb-3">Custom 3D Printing Service</h2>
      <p class="text-gray-400 max-w-lg">Upload your design, choose your material, and we'll print and deliver it to your door. Professional-grade printing with PLA, ABS, PETG, and more.</p>
      <div class="flex flex-wrap gap-3 mt-4 text-sm text-gray-400">
        <span class="flex items-center gap-1">✓ PLA / ABS / PETG</span>
        <span class="flex items-center gap-1">✓ Fast turnaround</span>
        <span class="flex items-center gap-1">✓ Pan-India delivery</span>
      </div>
    </div>
    <a href="/3d-printing" class="flex-shrink-0 px-8 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all hover:scale-105 shadow-lg shadow-blue-500/20 whitespace-nowrap">
      Get a Quote →
    </a>
  </div>
</section>

<!-- Blogs -->
<?php if(!empty($blogs['items'])): ?>
<section class="max-w-7xl mx-auto px-4 pb-16">
  <div class="flex items-center justify-between mb-8">
    <div><h2 class="text-2xl font-bold text-white">Latest from the Blog</h2><p class="text-gray-400 text-sm mt-1">Tips, tutorials, and maker stories</p></div>
    <a href="/blogs" class="text-blue-400 hover:text-blue-300 text-sm">View All →</a>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <?php foreach($blogs['items'] as $b): ?>
    <a href="/blogs/<?= clean($b['slug']) ?>" class="group block rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 overflow-hidden transition-all hover:-translate-y-1">
      <?php if($b['thumbnail']): ?>
      <div class="h-44 overflow-hidden">
        <img src="<?= clean($b['thumbnail']) ?>" alt="<?= clean($b['title']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
      </div>
      <?php else: ?>
      <div class="h-44 bg-gradient-to-br from-blue-900/30 to-cyan-900/30 flex items-center justify-center text-5xl">📝</div>
      <?php endif; ?>
      <div class="p-5">
        <?php if($b['category']): ?><span class="text-xs text-blue-400 font-medium"><?= clean($b['category']) ?></span><?php endif; ?>
        <h3 class="font-semibold text-white group-hover:text-blue-400 mt-1 transition-colors line-clamp-2"><?= clean($b['title']) ?></h3>
        <p class="text-gray-400 text-sm mt-2 line-clamp-2"><?= clean($b['excerpt']??'') ?></p>
        <div class="flex items-center gap-3 mt-3 text-xs text-gray-500">
          <span>by <?= clean($b['author_name']??'TT Electro') ?></span>
          <?php if($b['reading_time']): ?><span>· <?= $b['reading_time'] ?> min read</span><?php endif; ?>
        </div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- FAQ -->
<?php if(!empty($faqs)): ?>
<section class="max-w-3xl mx-auto px-4 pb-16">
  <div class="text-center mb-8">
    <h2 class="text-2xl font-bold text-white">Frequently Asked Questions</h2>
    <p class="text-gray-400 text-sm mt-1">Quick answers to common questions</p>
  </div>
  <div class="space-y-3">
    <?php foreach(array_slice($faqs,0,6) as $f): ?>
    <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5" x-data="{open:false}">
      <button @click="open=!open" class="w-full flex items-center justify-between px-5 py-4 text-left">
        <span class="font-medium text-gray-200 text-sm"><?= clean($f['question']) ?></span>
        <svg class="w-4 h-4 text-gray-400 transition-transform flex-shrink-0" :class="open && 'rotate-180'" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
      </button>
      <div x-show="open" x-transition class="px-5 pb-4 text-sm text-gray-400 leading-relaxed border-t border-white/5 pt-3">
        <?= clean($f['answer']) ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="text-center mt-6">
    <a href="/faq" class="text-blue-400 hover:text-blue-300 text-sm">View all FAQs →</a>
  </div>
</section>
<?php endif; ?>

<script>
function heroSlider() {
  return {
    current: 0,
    total: <?= count($banners) ?: 1 ?>,
    init() { if(this.total > 1) setInterval(() => this.next(), 5000); },
    next() { this.current = (this.current + 1) % this.total; },
    prev() { this.current = (this.current - 1 + this.total) % this.total; }
  }
}
function countdown(endTime) {
  return {
    hours: '00', minutes: '00', seconds: '00',
    init() {
      this.tick();
      setInterval(() => this.tick(), 1000);
    },
    tick() {
      const diff = Math.max(0, endTime * 1000 - Date.now());
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      this.hours   = String(h).padStart(2,'0');
      this.minutes = String(m).padStart(2,'0');
      this.seconds = String(s).padStart(2,'0');
    }
  }
}
</script>
