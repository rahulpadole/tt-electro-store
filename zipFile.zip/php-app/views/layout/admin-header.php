<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? clean($pageTitle).' – Admin' : 'Admin – '.APP_NAME ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode:'class',
      theme:{ extend:{ colors:{
        primary:{DEFAULT:'hsl(217,91%,62%)'},
        accent:{DEFAULT:'hsl(188,95%,50%)'},
      }}}
    }
  </script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
  <style>
    body{font-family:'Inter',sans-serif;}
    .dark body{background:hsl(222,47%,6%);}
    .toast-container{position:fixed;bottom:1.5rem;right:1.5rem;z-index:9999;display:flex;flex-direction:column;gap:.5rem;}
    .toast{padding:.75rem 1.25rem;border-radius:.5rem;color:#fff;font-size:.875rem;max-width:22rem;background:#1e293b;border-left:4px solid hsl(217,91%,62%);box-shadow:0 10px 30px rgba(0,0,0,.4);animation:slide-in .3s ease;}
    .toast.success{border-left-color:#22c55e;}.toast.error{border-left-color:#ef4444;}
    @keyframes slide-in{from{opacity:0;transform:translateX(2rem);}to{opacity:1;transform:none;}}
    ::-webkit-scrollbar{width:4px;}::-webkit-scrollbar-track{background:transparent;}::-webkit-scrollbar-thumb{background:#334155;border-radius:2px;}
  </style>
</head>
<body class="dark bg-[hsl(222,47%,6%)] text-gray-100 min-h-screen" x-data="{sidebarOpen:true}">
<div class="toast-container" id="toastContainer"></div>
<div class="flex min-h-screen">
  <!-- Sidebar -->
  <?php require __DIR__ . '/admin-sidebar.php'; ?>
  <!-- Main -->
  <div class="flex-1 flex flex-col min-w-0">
    <!-- Top bar -->
    <header class="h-14 bg-[hsl(222,47%,8%)] border-b border-white/10 flex items-center justify-between px-6 flex-shrink-0">
      <div class="flex items-center gap-3">
        <button @click="sidebarOpen=!sidebarOpen" class="text-gray-400 hover:text-white">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <h1 class="font-semibold text-white text-sm"><?= isset($pageTitle) ? clean($pageTitle) : 'Dashboard' ?></h1>
      </div>
      <div class="flex items-center gap-3">
        <a href="/" target="_blank" class="text-xs text-gray-400 hover:text-white transition-colors">← View Store</a>
        <div class="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white text-xs font-bold">
          <?= strtoupper(substr($currentUser['name']??'A',0,1)) ?>
        </div>
        <span class="text-sm text-gray-300"><?= clean($currentUser['name']??'Admin') ?></span>
        <a href="#" onclick="fetch('/api/auth/logout',{method:'POST'}).then(()=>location.href='/admin/login')" class="text-xs text-red-400 hover:text-red-300">Logout</a>
      </div>
    </header>
    <!-- Page content -->
    <main class="flex-1 p-6 overflow-auto">
