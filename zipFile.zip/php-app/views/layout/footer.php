</main>

<!-- Footer -->
<footer class="bg-[hsl(222,47%,6%)] border-t border-white/10 mt-20">
  <div class="max-w-7xl mx-auto px-4 py-12">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      <div>
        <div class="flex items-center gap-2 mb-4">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
            <span class="text-white font-bold text-sm">TT</span>
          </div>
          <span class="text-white font-bold text-lg">TT <span class="text-cyan-400">ELECTRO</span></span>
        </div>
        <p class="text-gray-400 text-sm leading-relaxed">Premium electronics for makers, engineers, and DIY enthusiasts across India.</p>
        <div class="flex gap-3 mt-4">
          <a href="#" class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/20 transition-all text-xs font-bold">in</a>
          <a href="#" class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/20 transition-all text-xs font-bold">tw</a>
          <a href="#" class="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/20 transition-all text-xs font-bold">yt</a>
        </div>
      </div>

      <div>
        <h4 class="text-white font-semibold mb-4">Quick Links</h4>
        <ul class="space-y-2 text-sm text-gray-400">
          <li><a href="/products" class="hover:text-white transition-colors">All Products</a></li>
          <li><a href="/diy-kits" class="hover:text-white transition-colors">DIY Vision Kits</a></li>
          <li><a href="/3d-printing" class="hover:text-white transition-colors">3D Printing Service</a></li>
          <li><a href="/offers" class="hover:text-white transition-colors">Offers & Flash Sales</a></li>
          <li><a href="/blogs" class="hover:text-white transition-colors">Tech Blog</a></li>
        </ul>
      </div>

      <div>
        <h4 class="text-white font-semibold mb-4">Support</h4>
        <ul class="space-y-2 text-sm text-gray-400">
          <li><a href="/track-order" class="hover:text-white transition-colors">Track Order</a></li>
          <li><a href="/faq" class="hover:text-white transition-colors">FAQ</a></li>
          <li><a href="/contact" class="hover:text-white transition-colors">Contact Us</a></li>
          <li><a href="/about" class="hover:text-white transition-colors">About Us</a></li>
          <li><a href="/privacy-policy" class="hover:text-white transition-colors">Privacy Policy</a></li>
          <li><a href="/terms" class="hover:text-white transition-colors">Terms of Service</a></li>
        </ul>
      </div>

      <div>
        <h4 class="text-white font-semibold mb-4">Newsletter</h4>
        <p class="text-gray-400 text-sm mb-3">Get exclusive deals and tech updates.</p>
        <form x-data="{email:'',loading:false}" @submit.prevent="
          loading=true;
          fetch('/api/newsletter/subscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})})
            .then(r=>r.json()).then(d=>{ showToast(d.message,'success'); email=''; }).catch(()=>showToast('Error','error')).finally(()=>loading=false)">
          <div class="flex gap-2">
            <input type="email" x-model="email" required placeholder="your@email.com"
                   class="flex-1 px-3 py-2 rounded-lg bg-white/10 border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500">
            <button type="submit" :disabled="loading" class="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm transition-colors disabled:opacity-50">
              <svg x-show="!loading" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
              <span x-show="loading" class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin inline-block"></span>
            </button>
          </div>
        </form>
        <div class="mt-4 text-sm text-gray-400">
          <p>📞 +91 98765 43210</p>
          <p>✉️ support@ttelectro.in</p>
          <p>⏰ Mon–Sat 9am–6pm IST</p>
        </div>
      </div>
    </div>

    <div class="border-t border-white/10 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
      <p class="text-gray-500 text-sm">© <?= date('Y') ?> <?= APP_NAME ?>. All rights reserved.</p>
      <div class="flex items-center gap-4 text-sm text-gray-500">
        <span>🇮🇳 Made in India</span>
        <span>COD Available</span>
        <span>Free Returns</span>
      </div>
    </div>
  </div>
</footer>

<!-- WhatsApp Float Button -->
<a href="https://wa.me/919876543210" target="_blank" rel="noopener"
   class="fixed bottom-6 left-6 z-50 w-12 h-12 rounded-full bg-green-500 hover:bg-green-400 flex items-center justify-center shadow-lg transition-all hover:scale-110"
   title="Chat on WhatsApp">
  <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
</a>

<!-- Global JS -->
<script>
function appState() {
  return {
    isDark: document.documentElement.classList.contains('dark'),
    mobileOpen: false,
    toggleTheme() {
      this.isDark = !this.isDark;
      document.documentElement.classList.toggle('dark', this.isDark);
      localStorage.setItem('theme', this.isDark ? 'dark' : 'light');
    }
  }
}
function navbar() { return { mobileOpen: false }; }

function showToast(msg, type='info') {
  const c = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

// Global fetch helper
async function apiFetch(url, opts={}) {
  const defaults = { headers: { 'Content-Type': 'application/json' } };
  const res = await fetch(url, { ...defaults, ...opts, headers: { ...defaults.headers, ...(opts.headers||{}) } });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
}

// Cart
async function addToCart(productId, qty=1) {
  try {
    await apiFetch('/api/cart', { method: 'POST', body: JSON.stringify({ product_id: productId, quantity: qty }) });
    showToast('Added to cart!', 'success');
    // Update badge
    const badge = document.querySelector('#cartBadge');
    if(badge) badge.textContent = parseInt(badge.textContent||0)+qty;
  } catch(e) { showToast(e.message, 'error'); }
}

async function addToWishlist(productId) {
  try {
    await apiFetch('/api/wishlist', { method: 'POST', body: JSON.stringify({ product_id: productId }) });
    showToast('Added to wishlist!', 'success');
  } catch(e) { showToast(e.message, 'error'); }
}
</script>
</body>
</html>
