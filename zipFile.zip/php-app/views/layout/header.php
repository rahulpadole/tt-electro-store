<!DOCTYPE html>
<html lang="en" class="dark" x-data x-init="
  const theme = localStorage.getItem('theme') || 'dark';
  document.documentElement.classList.toggle('dark', theme === 'dark');
">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? clean($pageTitle).' – '.APP_NAME : APP_NAME ?></title>
  <meta name="description" content="<?= isset($pageDesc) ? clean($pageDesc) : 'Premium electronics for makers, engineers and DIY enthusiasts in India.' ?>">
  <link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon">

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            primary:  { DEFAULT: 'hsl(217,91%,62%)',  foreground: '#fff' },
            accent:   { DEFAULT: 'hsl(188,95%,50%)',  foreground: '#000' },
            dark:     { DEFAULT: 'hsl(222,47%,6%)',   card: 'hsl(222,47%,10%)' },
          },
          fontFamily: { sans: ['Inter','ui-sans-serif','system-ui'] },
        }
      }
    }
  </script>

  <!-- Alpine.js -->
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>

  <!-- Sonner-style toast (hand-rolled) -->
  <style>
    :root { --primary: hsl(217,91%,62%); --accent: hsl(188,95%,50%); }
    .dark body { background-color: hsl(222,47%,6%); color: #e2e8f0; }
    body { font-family: 'Inter', sans-serif; }
    .toast-container { position:fixed; bottom:1.5rem; right:1.5rem; z-index:9999; display:flex; flex-direction:column; gap:.5rem; }
    .toast { padding:.75rem 1.25rem; border-radius:.5rem; color:#fff; font-size:.875rem; max-width:22rem;
             background:#1e293b; border-left:4px solid var(--primary); box-shadow:0 10px 30px rgba(0,0,0,.4);
             animation: slide-in .3s ease; }
    .toast.success { border-left-color:#22c55e; }
    .toast.error   { border-left-color:#ef4444; }
    @keyframes slide-in { from{ opacity:0; transform:translateX(2rem); } to{ opacity:1; transform:none; } }
    /* Scrollbar */
    ::-webkit-scrollbar { width:6px; } ::-webkit-scrollbar-track { background:transparent; }
    ::-webkit-scrollbar-thumb { background:#334155; border-radius:3px; }
    /* Transitions */
    .fade-in { animation: fadeIn .4s ease; }
    @keyframes fadeIn { from{ opacity:0; transform:translateY(8px); } to{ opacity:1; transform:none; } }
  </style>
  <link rel="stylesheet" href="/assets/css/custom.css">
</head>
<body class="dark:bg-[hsl(222,47%,6%)] bg-gray-50 text-gray-900 dark:text-gray-100 min-h-screen" x-data="appState()">

<!-- Toast container -->
<div class="toast-container" id="toastContainer"></div>

<!-- Navbar -->
<?php require __DIR__ . '/navbar.php'; ?>
