<nav class="sticky top-0 z-50 bg-[hsl(222,47%,8%)] dark:bg-[hsl(222,47%,8%)] border-b border-white/10 backdrop-blur-lg" x-data="navbar()">
  <div class="max-w-7xl mx-auto px-4 flex items-center justify-between h-16 gap-4">

    <!-- Logo -->
    <a href="/" class="flex items-center gap-2 flex-shrink-0">
      <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
        <span class="text-white font-bold text-sm">TT</span>
      </div>
      <span class="text-white font-bold text-lg hidden sm:block">TT <span class="text-cyan-400">ELECTRO</span></span>
    </a>

    <!-- Desktop Nav Links -->
    <div class="hidden lg:flex items-center gap-6 text-sm text-gray-300">
      <div class="relative group" x-data="{open:false}" @mouseenter="open=true" @mouseleave="open=false">
        <button class="flex items-center gap-1 hover:text-white transition-colors py-2">
          Products
          <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div x-show="open" x-transition class="absolute top-full left-0 mt-1 w-48 bg-[hsl(222,47%,12%)] border border-white/10 rounded-xl shadow-2xl overflow-hidden">
          <?php
          $cats = (new CategoryModel())->all();
          foreach(array_slice($cats,0,8) as $cat): ?>
          <a href="/products?category_id=<?= $cat['id'] ?>" class="block px-4 py-2.5 text-gray-300 hover:text-white hover:bg-white/5 text-sm transition-colors">
            <?= clean($cat['name']) ?>
          </a>
          <?php endforeach; ?>
          <a href="/products" class="block px-4 py-2.5 text-cyan-400 hover:bg-white/5 text-sm font-medium border-t border-white/10">View All →</a>
        </div>
      </div>
      <a href="/diy-kits"    class="hover:text-white transition-colors">DIY Kits</a>
      <a href="/3d-printing" class="hover:text-white transition-colors">3D Printing</a>
      <a href="/offers"      class="hover:text-white transition-colors text-yellow-400">Offers</a>
      <a href="/blogs"       class="hover:text-white transition-colors">Blogs</a>
      <a href="/track-order" class="hover:text-white transition-colors">Track Order</a>
    </div>

    <!-- Search Bar -->
    <form action="/products" method="GET" class="hidden md:flex flex-1 max-w-sm">
      <div class="relative w-full">
        <input type="text" name="q" placeholder="Search products..."
               class="w-full pl-4 pr-10 py-2 rounded-lg bg-white/10 border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 focus:bg-white/15 transition-all">
        <button type="submit" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35" stroke-linecap="round"/></svg>
        </button>
      </div>
    </form>

    <!-- Right Icons -->
    <div class="flex items-center gap-2">
      <!-- Theme toggle -->
      <button @click="toggleTheme()" class="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all" title="Toggle theme">
        <svg x-show="isDark" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707M18.364 18.364l-.707-.707M6.343 6.343l-.707-.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
        <svg x-show="!isDark" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
      </button>

      <!-- Notifications -->
      <?php if(isLoggedIn()): ?>
      <a href="/notifications" class="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
        <?php
        $unread = (new NotificationModel())->unreadCount(getCurrentUserId());
        if($unread > 0): ?>
        <span class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-xs flex items-center justify-center text-white font-bold"><?= $unread ?></span>
        <?php endif; ?>
      </a>
      <?php endif; ?>

      <!-- Wishlist -->
      <a href="/wishlist" class="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
        <?php
        $wCount = (new WishlistModel())->count(getCurrentUserId());
        if($wCount > 0): ?>
        <span class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-pink-500 rounded-full text-xs flex items-center justify-center text-white font-bold"><?= $wCount ?></span>
        <?php endif; ?>
      </a>

      <!-- Cart -->
      <a href="/cart" class="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
        <?php
        $cartCount = (new CartModel())->count(getCurrentUserId());
        if($cartCount > 0): ?>
        <span class="absolute -top-0.5 -right-0.5 w-4 h-4 bg-blue-500 rounded-full text-xs flex items-center justify-center text-white font-bold"><?= $cartCount ?></span>
        <?php endif; ?>
      </a>

      <!-- User -->
      <?php if(isLoggedIn()): ?>
      <div class="relative" x-data="{open:false}" @click.outside="open=false">
        <button @click="open=!open" class="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-all">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
        </button>
        <div x-show="open" x-transition class="absolute right-0 top-full mt-1 w-48 bg-[hsl(222,47%,12%)] border border-white/10 rounded-xl shadow-2xl overflow-hidden">
          <div class="px-4 py-3 border-b border-white/10">
            <p class="text-sm font-medium text-white"><?= clean($currentUser['name']) ?></p>
            <p class="text-xs text-gray-400"><?= clean($currentUser['email']) ?></p>
          </div>
          <a href="/dashboard" class="block px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/5">Dashboard</a>
          <a href="/orders" class="block px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/5">My Orders</a>
          <?php if(isAdmin()): ?><a href="/admin" class="block px-4 py-2.5 text-sm text-cyan-400 hover:bg-white/5">Admin Panel</a><?php endif; ?>
          <a href="#" onclick="fetch('/api/auth/logout',{method:'POST'}).then(()=>location.href='/')" class="block px-4 py-2.5 text-sm text-red-400 hover:bg-white/5 border-t border-white/10">Sign Out</a>
        </div>
      </div>
      <?php else: ?>
      <a href="/login" class="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium transition-colors">Login</a>
      <?php endif; ?>

      <!-- Mobile menu -->
      <button @click="mobileOpen=!mobileOpen" class="lg:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/10">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
    </div>
  </div>

  <!-- Mobile menu -->
  <div x-show="mobileOpen" x-transition class="lg:hidden border-t border-white/10 bg-[hsl(222,47%,8%)] px-4 py-3 space-y-1">
    <a href="/products" class="block py-2 text-gray-300 hover:text-white text-sm">Products</a>
    <a href="/diy-kits" class="block py-2 text-gray-300 hover:text-white text-sm">DIY Kits</a>
    <a href="/3d-printing" class="block py-2 text-gray-300 hover:text-white text-sm">3D Printing</a>
    <a href="/offers" class="block py-2 text-yellow-400 hover:text-yellow-300 text-sm">Offers</a>
    <a href="/blogs" class="block py-2 text-gray-300 hover:text-white text-sm">Blogs</a>
    <a href="/track-order" class="block py-2 text-gray-300 hover:text-white text-sm">Track Order</a>
    <form action="/products" method="GET" class="pt-2">
      <input type="text" name="q" placeholder="Search..." class="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none">
    </form>
  </div>
</nav>

<!-- Main content wrapper -->
<main>
