<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Login – <?= APP_NAME ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>tailwind.config={darkMode:'class'}</script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
  <style>body{font-family:sans-serif;}</style>
</head>
<body class="dark bg-[hsl(222,47%,6%)] text-gray-100 min-h-screen flex items-center justify-center p-4">
<div class="toast-container fixed bottom-6 right-6 z-50 flex flex-col gap-2" id="toastContainer"></div>

<div class="w-full max-w-md">
  <div class="text-center mb-8">
    <a href="/" class="inline-flex items-center gap-2">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center"><span class="text-white font-bold">TT</span></div>
      <span class="text-white font-bold text-xl">TT <span class="text-cyan-400">ELECTRO</span></span>
    </a>
    <h1 class="text-2xl font-bold text-white mt-4">Welcome back!</h1>
    <p class="text-gray-400 text-sm mt-1">Sign in to your account</p>
  </div>

  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-8" x-data="loginForm()">
    <div class="space-y-4">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Email Address</label>
        <input type="email" x-model="email" placeholder="you@example.com" @keydown.enter="submit()"
               class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Password</label>
        <div class="relative">
          <input :type="showPw?'text':'password'" x-model="password" placeholder="Your password" @keydown.enter="submit()"
                 class="w-full px-4 py-3 pr-10 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 transition-colors">
          <button @click="showPw=!showPw" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 text-xs">
            <span x-text="showPw?'Hide':'Show'"></span>
          </button>
        </div>
      </div>
      <p x-show="error" x-text="error" class="text-red-400 text-sm bg-red-500/10 px-3 py-2 rounded-lg border border-red-500/20"></p>
      <button @click="submit()" :disabled="loading"
              class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed mt-2">
        <span x-show="!loading">Sign In →</span>
        <span x-show="loading" class="flex items-center justify-center gap-2">
          <span class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>Signing in...
        </span>
      </button>
    </div>
    <p class="text-center text-gray-400 text-sm mt-6">
      Don't have an account? <a href="/register" class="text-blue-400 hover:text-blue-300 font-medium">Create one →</a>
    </p>
  </div>
</div>

<script>
function showToast(msg,type='info'){const c=document.getElementById('toastContainer');const t=document.createElement('div');t.style.cssText='padding:.75rem 1.25rem;border-radius:.5rem;color:#fff;font-size:.875rem;background:#1e293b;border-left:4px solid '+(type==='success'?'#22c55e':'#ef4444')+';box-shadow:0 10px 30px rgba(0,0,0,.4);';t.textContent=msg;c.appendChild(t);setTimeout(()=>t.remove(),3500);}
function loginForm() {
  return {
    email: '', password: '', loading: false, error: '', showPw: false,
    async submit() {
      if(!this.email||!this.password){this.error='Please fill all fields';return;}
      this.loading = true; this.error = '';
      try {
        await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:this.email,password:this.password})})
          .then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.message||'Login failed');return d;});
        location.href = '<?= $_GET['redirect'] ?? '/dashboard' ?>';
      } catch(e) { this.error = e.message; }
      this.loading = false;
    }
  }
}
</script>
</body></html>
