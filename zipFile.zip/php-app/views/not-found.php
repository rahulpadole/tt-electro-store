<?php $pageTitle = 'Page Not Found'; ?>
<div class="min-h-[60vh] flex items-center justify-center px-4">
  <div class="text-center">
    <div class="text-8xl font-black text-blue-500/20 mb-4">404</div>
    <h1 class="text-3xl font-bold text-white mb-3">Page Not Found</h1>
    <p class="text-gray-400 mb-8 max-w-md mx-auto">The page you're looking for doesn't exist or has been moved.</p>
    <div class="flex items-center justify-center gap-3 flex-wrap">
      <a href="/" class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">← Go Home</a>
      <a href="/products" class="px-6 py-3 rounded-xl border border-white/10 hover:bg-white/5 text-gray-300 font-medium transition-all">Browse Products</a>
    </div>
  </div>
</div>
