<?php
$pageTitle = 'My Orders';
$om = new OrderModel();
$orders = $om->getForUser(getCurrentUserId());
$statusColors = ['pending'=>'yellow','processing'=>'blue','shipped'=>'purple','delivered'=>'green','cancelled'=>'red'];
?>
<div class="max-w-4xl mx-auto px-4 py-8">
  <h1 class="text-2xl font-bold text-white mb-6">My Orders</h1>
  <?php if(empty($orders)): ?>
  <div class="text-center py-20">
    <div class="text-6xl mb-4">📦</div>
    <p class="text-gray-400 text-lg font-medium mb-2">No orders yet</p>
    <a href="/products" class="mt-2 inline-block px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium">Start Shopping →</a>
  </div>
  <?php else: ?>
  <div class="space-y-4">
    <?php foreach($orders as $order):
      $sc = $statusColors[$order['status']] ?? 'gray';
    ?>
    <a href="/orders/<?= $order['id'] ?>" class="block rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 p-5 transition-all hover:-translate-y-0.5">
      <div class="flex items-center justify-between flex-wrap gap-3">
        <div>
          <p class="text-white font-semibold"><?= clean($order['order_number']) ?></p>
          <p class="text-gray-400 text-sm mt-0.5"><?= date('M j, Y', strtotime($order['created_at'])) ?></p>
        </div>
        <div class="flex items-center gap-4">
          <span class="px-3 py-1 rounded-full text-xs font-semibold bg-<?= $sc ?>-500/20 text-<?= $sc ?>-400 border border-<?= $sc ?>-500/30 capitalize">
            <?= clean($order['status']) ?>
          </span>
          <span class="text-white font-bold">₹<?= number_format((float)$order['total'],2) ?></span>
        </div>
      </div>
      <?php if($order['tracking_number']): ?>
      <p class="text-xs text-gray-500 mt-2">Tracking: <span class="text-blue-400"><?= clean($order['tracking_number']) ?></span></p>
      <?php endif; ?>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
