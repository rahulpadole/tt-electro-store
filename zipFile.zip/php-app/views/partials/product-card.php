<?php
// Expects $p = product array
$salePrice = ($p['is_flash_sale'] && $p['flash_sale_price']) ? (float)$p['flash_sale_price'] : null;
$displayPrice = $salePrice ?? (float)$p['price'];
$originalPrice = (float)$p['original_price'] ?: (float)$p['price'];
$discPct = $salePrice && $originalPrice > $displayPrice ? round((1 - $displayPrice/$originalPrice)*100) : 0;
?>
<div class="group relative rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-blue-500/20 overflow-hidden transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-500/10 flex flex-col">
  <!-- Image -->
  <a href="/products/<?= $p['id'] ?>" class="block relative overflow-hidden">
    <?php if($p['thumbnail']): ?>
    <img src="<?= clean($p['thumbnail']) ?>" alt="<?= clean($p['name']) ?>"
         class="w-full h-44 object-cover group-hover:scale-105 transition-transform duration-500">
    <?php else: ?>
    <div class="w-full h-44 bg-gradient-to-br from-blue-900/30 to-cyan-900/30 flex items-center justify-center text-5xl">📦</div>
    <?php endif; ?>
    <?php if($discPct > 0): ?>
    <span class="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-red-500 text-white text-xs font-bold"><?= $discPct ?>% OFF</span>
    <?php endif; ?>
    <?php if($p['is_flash_sale']): ?>
    <span class="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-orange-500 text-white text-xs font-bold">⚡ SALE</span>
    <?php endif; ?>
    <?php if($p['stock'] <= 0): ?>
    <div class="absolute inset-0 bg-black/60 flex items-center justify-center">
      <span class="text-white font-semibold text-sm">Out of Stock</span>
    </div>
    <?php endif; ?>
  </a>

  <!-- Info -->
  <div class="p-3 flex flex-col flex-1">
    <?php if(!empty($p['brand_name'])): ?>
    <span class="text-xs text-gray-500 mb-1"><?= clean($p['brand_name']) ?></span>
    <?php endif; ?>
    <a href="/products/<?= $p['id'] ?>" class="text-sm font-medium text-gray-200 hover:text-white line-clamp-2 leading-snug flex-1">
      <?= clean($p['name']) ?>
    </a>

    <div class="mt-2 flex items-center justify-between">
      <div>
        <span class="text-base font-bold text-white">₹<?= number_format($displayPrice,2) ?></span>
        <?php if($salePrice && (float)$p['price'] > $displayPrice): ?>
        <span class="text-xs text-gray-500 line-through ml-1">₹<?= number_format((float)$p['price'],2) ?></span>
        <?php elseif($p['original_price'] && (float)$p['original_price'] > (float)$p['price']): ?>
        <span class="text-xs text-gray-500 line-through ml-1">₹<?= number_format((float)$p['original_price'],2) ?></span>
        <?php endif; ?>
      </div>
      <!-- Wishlist -->
      <button onclick="addToWishlist(<?= $p['id'] ?>)" class="p-1.5 rounded-lg text-gray-500 hover:text-pink-400 hover:bg-pink-500/10 transition-all">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
      </button>
    </div>

    <button onclick="addToCart(<?= $p['id'] ?>)"
            <?= $p['stock'] <= 0 ? 'disabled' : '' ?>
            class="mt-2 w-full py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 disabled:cursor-not-allowed text-white text-xs font-medium transition-colors">
      <?= $p['stock'] <= 0 ? 'Out of Stock' : 'Add to Cart' ?>
    </button>
  </div>
</div>
