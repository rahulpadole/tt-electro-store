<?php
$pm = new ProductModel();
$rm = new ReviewModel();
$product = $pm->findById($productId);
if(!$product){ http_response_code(404); include __DIR__.'/not-found.php'; return; }
$reviews = $rm->forProduct($productId);
$avgRating = $rm->avgRating($productId);
$related = $pm->all(['category_id'=>$product['category_id']],1,6);
$related['items'] = array_filter($related['items'],fn($r)=>$r['id']!=$productId);
$pageTitle = $product['name'];
$pageDesc  = $product['description']??$product['name'];
$images = is_array($product['images']) ? $product['images'] : [];
if($product['thumbnail'] && !in_array($product['thumbnail'],$images)) array_unshift($images,$product['thumbnail']);
if(empty($images)) $images = [''];
$salePrice = ($product['is_flash_sale'] && $product['flash_sale_price']) ? (float)$product['flash_sale_price'] : null;
$displayPrice = $salePrice ?? (float)$product['price'];
$specs = is_array($product['specifications']) ? $product['specifications'] : [];
?>
<div class="max-w-7xl mx-auto px-4 py-8" x-data="productDetail()">

  <!-- Breadcrumb -->
  <nav class="flex items-center gap-2 text-sm text-gray-500 mb-6">
    <a href="/" class="hover:text-gray-300">Home</a><span>/</span>
    <a href="/products" class="hover:text-gray-300">Products</a><span>/</span>
    <?php if($product['category_name']): ?><a href="/products?category_id=<?= $product['category_id'] ?>" class="hover:text-gray-300"><?= clean($product['category_name']) ?></a><span>/</span><?php endif; ?>
    <span class="text-gray-300 truncate"><?= clean($product['name']) ?></span>
  </nav>

  <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
    <!-- Image Gallery -->
    <div x-data="{current:0, images:<?= htmlspecialchars(json_encode($images),ENT_QUOTES) ?>}">
      <div class="rounded-2xl overflow-hidden bg-[hsl(222,47%,10%)] border border-white/5 mb-3 aspect-square flex items-center justify-center">
        <template x-if="images[current]">
          <img :src="images[current]" alt="<?= clean($product['name']) ?>" class="w-full h-full object-cover">
        </template>
        <template x-if="!images[current]">
          <div class="text-8xl">📦</div>
        </template>
      </div>
      <?php if(count($images) > 1): ?>
      <div class="flex gap-2 overflow-x-auto">
        <?php foreach($images as $i => $img): ?>
        <button @click="current=<?= $i ?>" :class="current===<?= $i ?>?'border-blue-500':'border-white/10'" class="flex-shrink-0 w-16 h-16 rounded-lg border-2 overflow-hidden transition-all">
          <?php if($img): ?><img src="<?= clean($img) ?>" class="w-full h-full object-cover"><?php else: ?><div class="w-full h-full flex items-center justify-center text-2xl">📦</div><?php endif; ?>
        </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Product Info -->
    <div class="space-y-5">
      <?php if($product['brand_name']): ?><span class="text-sm text-blue-400 font-medium"><?= clean($product['brand_name']) ?></span><?php endif; ?>
      <h1 class="text-2xl md:text-3xl font-bold text-white leading-tight"><?= clean($product['name']) ?></h1>

      <!-- Rating -->
      <div class="flex items-center gap-3">
        <div class="flex gap-0.5">
          <?php for($s=1;$s<=5;$s++): ?>
          <svg class="w-4 h-4 <?= $s<=$avgRating?'text-yellow-400':'text-gray-600' ?>" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
          <?php endfor; ?>
        </div>
        <span class="text-gray-400 text-sm"><?= $avgRating ?>/5 (<?= count($reviews) ?> reviews)</span>
      </div>

      <!-- Price -->
      <div class="flex items-end gap-3">
        <span class="text-3xl font-bold text-white">₹<?= number_format($displayPrice,2) ?></span>
        <?php if($salePrice && (float)$product['price']>$displayPrice): ?>
        <span class="text-lg text-gray-500 line-through">₹<?= number_format((float)$product['price'],2) ?></span>
        <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-sm font-bold"><?= round((1-$displayPrice/(float)$product['price'])*100) ?>% OFF</span>
        <?php elseif($product['original_price'] && (float)$product['original_price']>(float)$product['price']): ?>
        <span class="text-lg text-gray-500 line-through">₹<?= number_format((float)$product['original_price'],2) ?></span>
        <?php endif; ?>
      </div>

      <!-- Stock -->
      <?php $stock=(int)$product['stock']; ?>
      <div class="flex items-center gap-2">
        <?php if($stock>0): ?>
        <span class="flex items-center gap-1.5 text-green-400 text-sm"><span class="w-2 h-2 rounded-full bg-green-400 animate-pulse inline-block"></span>In Stock (<?= $stock ?> units)</span>
        <?php else: ?>
        <span class="text-red-400 text-sm">Out of Stock</span>
        <?php endif; ?>
      </div>

      <?php if($product['description']): ?>
      <p class="text-gray-400 leading-relaxed text-sm"><?= nl2br(clean($product['description'])) ?></p>
      <?php endif; ?>

      <!-- Tags -->
      <?php if(!empty($product['tags'])): ?>
      <div class="flex flex-wrap gap-2">
        <?php foreach($product['tags'] as $tag): ?>
        <span class="px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 text-xs border border-blue-500/20"><?= clean($tag) ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Quantity & Actions -->
      <div class="flex items-center gap-3 pt-2">
        <div class="flex items-center gap-2 bg-[hsl(222,47%,12%)] border border-white/10 rounded-xl px-1">
          <button @click="qty=Math.max(1,qty-1)" class="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white text-lg">−</button>
          <span x-text="qty" class="w-6 text-center text-white font-medium text-sm"></span>
          <button @click="qty=Math.min(<?= $stock ?>,qty+1)" class="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white text-lg">+</button>
        </div>
        <button @click="addToCartQty(<?= $product['id'] ?>,qty)" <?= $stock<=0?'disabled':'' ?>
                class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 text-white font-semibold transition-all hover:scale-[1.02] disabled:cursor-not-allowed text-sm">
          🛒 Add to Cart
        </button>
        <button onclick="addToWishlist(<?= $product['id'] ?>)" class="p-3 rounded-xl border border-white/10 hover:border-pink-500/30 hover:bg-pink-500/10 text-gray-400 hover:text-pink-400 transition-all">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
        </button>
      </div>

      <!-- Delivery info -->
      <div class="grid grid-cols-3 gap-3 pt-3 border-t border-white/10">
        <?php foreach([['🚚','Fast Delivery','5-7 days'],['🛡️','Genuine','100% authentic'],['↩️','Returns','1-day policy']] as [$icon,$t,$s]): ?>
        <div class="text-center p-3 rounded-xl bg-[hsl(222,47%,10%)] border border-white/5">
          <div class="text-lg mb-1"><?= $icon ?></div>
          <div class="text-xs font-medium text-gray-300"><?= $t ?></div>
          <div class="text-xs text-gray-500"><?= $s ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Specifications -->
  <?php if(!empty($specs)): ?>
  <div class="mt-12">
    <h2 class="text-xl font-bold text-white mb-4">Specifications</h2>
    <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 overflow-hidden">
      <?php $i=0; foreach((is_array($specs)?$specs:[]) as $k=>$v): ?>
      <div class="flex <?= $i%2==0?'bg-white/[0.02]':'' ?>">
        <div class="w-1/3 px-4 py-3 text-sm text-gray-400 font-medium border-r border-white/5"><?= clean(is_string($k)?$k:'') ?></div>
        <div class="flex-1 px-4 py-3 text-sm text-gray-300"><?= clean(is_string($v)?$v:json_encode($v)) ?></div>
      </div>
      <?php $i++; endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Reviews -->
  <div class="mt-12">
    <div class="flex items-center justify-between mb-6">
      <h2 class="text-xl font-bold text-white">Customer Reviews (<?= count($reviews) ?>)</h2>
      <?php if(isLoggedIn()): ?>
      <button @click="reviewOpen=!reviewOpen" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium transition-colors">Write a Review</button>
      <?php endif; ?>
    </div>

    <!-- Write Review Form -->
    <?php if(isLoggedIn()): ?>
    <div x-show="reviewOpen" x-transition class="mb-6 p-5 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10">
      <h3 class="font-semibold text-white mb-4">Your Review</h3>
      <div x-data="reviewForm(<?= $product['id'] ?>)">
        <!-- Star Rating -->
        <div class="flex gap-1 mb-3">
          <?php for($s=1;$s<=5;$s++): ?>
          <button @click="rating=<?= $s ?>" :class="rating>= <?= $s ?> ? 'text-yellow-400':'text-gray-600'" class="text-2xl transition-colors hover:text-yellow-400">★</button>
          <?php endfor; ?>
        </div>
        <input type="text" x-model="title" placeholder="Review title" class="w-full mb-2 px-3 py-2 rounded-lg bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
        <textarea x-model="body" rows="3" placeholder="Share your experience..." class="w-full mb-3 px-3 py-2 rounded-lg bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 resize-none"></textarea>
        <button @click="submit()" :disabled="loading" class="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium transition-colors disabled:opacity-50">
          <span x-show="!loading">Submit Review</span>
          <span x-show="loading">Submitting...</span>
        </button>
      </div>
    </div>
    <?php endif; ?>

    <!-- Reviews List -->
    <?php if(empty($reviews)): ?>
    <p class="text-gray-500 text-sm">No reviews yet. Be the first to review this product!</p>
    <?php else: ?>
    <div class="space-y-4">
      <?php foreach($reviews as $r): ?>
      <div class="p-4 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5">
        <div class="flex items-start justify-between gap-3">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center text-white font-bold text-xs">
              <?= strtoupper(substr($r['user_name']??'U',0,1)) ?>
            </div>
            <div>
              <p class="text-sm font-medium text-white"><?= clean($r['user_name']??'User') ?></p>
              <p class="text-xs text-gray-500"><?= date('M j, Y',strtotime($r['created_at'])) ?></p>
            </div>
          </div>
          <div class="flex gap-0.5">
            <?php for($s=1;$s<=5;$s++): ?>
            <svg class="w-3.5 h-3.5 <?= $s<=(int)$r['rating']?'text-yellow-400':'text-gray-600' ?>" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
            <?php endfor; ?>
          </div>
        </div>
        <?php if($r['title']): ?><p class="font-medium text-gray-200 text-sm mt-2"><?= clean($r['title']) ?></p><?php endif; ?>
        <?php if($r['body']): ?><p class="text-gray-400 text-sm mt-1"><?= clean($r['body']) ?></p><?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <!-- Related Products -->
  <?php if(!empty($related['items'])): ?>
  <div class="mt-12">
    <h2 class="text-xl font-bold text-white mb-6">Related Products</h2>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
      <?php foreach(array_slice($related['items'],0,6) as $p): include __DIR__ . '/partials/product-card.php'; endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
function productDetail() {
  return {
    qty: 1,
    reviewOpen: false,
    async addToCartQty(id, qty) {
      try {
        await apiFetch('/api/cart', { method: 'POST', body: JSON.stringify({ product_id: id, quantity: qty }) });
        showToast('Added to cart!', 'success');
      } catch(e) { showToast(e.message, 'error'); }
    }
  }
}
function reviewForm(productId) {
  return {
    rating: 5, title: '', body: '', loading: false,
    async submit() {
      if(!this.rating) { showToast('Please select a rating', 'error'); return; }
      this.loading = true;
      try {
        await apiFetch(`/api/products/${productId}/reviews`, { method: 'POST', body: JSON.stringify({ rating: this.rating, title: this.title, body: this.body }) });
        showToast('Review submitted!', 'success');
        setTimeout(() => location.reload(), 1000);
      } catch(e) { showToast(e.message, 'error'); }
      this.loading = false;
    }
  }
}
</script>
