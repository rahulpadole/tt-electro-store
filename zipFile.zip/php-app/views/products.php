<?php
$pageTitle = 'Products';
$pm = new ProductModel();
$cm = new CategoryModel();
$bm = new BrandModel();

$filters = [
  'q'           => trim($_GET['q']   ?? ''),
  'category_id' => $_GET['category_id'] ?? '',
  'brand_id'    => $_GET['brand_id']    ?? '',
  'min_price'   => $_GET['min_price']   ?? '',
  'max_price'   => $_GET['max_price']   ?? '',
  'sort'        => $_GET['sort']        ?? 'newest',
];
$page     = max(1,(int)($_GET['page'] ?? 1));
$result   = $pm->all($filters, $page);
$cats     = $cm->all();
$brands   = $bm->all();

$queryString = http_build_query(array_filter([
  'q'           => $filters['q'],
  'category_id' => $filters['category_id'],
  'brand_id'    => $filters['brand_id'],
  'min_price'   => $filters['min_price'],
  'max_price'   => $filters['max_price'],
  'sort'        => $filters['sort'] !== 'newest' ? $filters['sort'] : '',
]));
?>
<div class="max-w-7xl mx-auto px-4 py-8">
  <div class="flex flex-col lg:flex-row gap-8">

    <!-- Sidebar Filters -->
    <aside class="lg:w-64 flex-shrink-0" x-data="{filtersOpen:false}">
      <button @click="filtersOpen=!filtersOpen" class="lg:hidden mb-4 w-full py-2 rounded-xl bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 text-sm flex items-center justify-center gap-2">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 010 2H4a1 1 0 01-1-1zM6 12a1 1 0 011-1h10a1 1 0 010 2H7a1 1 0 01-1-1zM9 19a1 1 0 011-1h4a1 1 0 010 2h-4a1 1 0 01-1-1z"/></svg>
        Filters
      </button>

      <div class="space-y-6" :class="{'hidden lg:block': !filtersOpen, 'block': filtersOpen}">
        <form action="/products" method="GET" id="filterForm">
          <?php if($filters['q']): ?><input type="hidden" name="q" value="<?= clean($filters['q']) ?>"><?php endif; ?>

          <!-- Sort -->
          <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-4">
            <h3 class="text-sm font-semibold text-white mb-3">Sort By</h3>
            <select name="sort" onchange="this.form.submit()" class="w-full bg-[hsl(222,47%,13%)] border border-white/10 text-gray-300 text-sm rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500">
              <?php foreach(['newest'=>'Newest First','price_asc'=>'Price: Low to High','price_desc'=>'Price: High to Low','popular'=>'Most Popular'] as $val => $label): ?>
              <option value="<?= $val ?>" <?= $filters['sort']===$val?'selected':'' ?>><?= $label ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <!-- Categories -->
          <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-4">
            <h3 class="text-sm font-semibold text-white mb-3">Categories</h3>
            <div class="space-y-2 max-h-48 overflow-y-auto">
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="category_id" value="" <?= empty($filters['category_id'])?'checked':'' ?> class="accent-blue-500" onchange="this.form.submit()">
                <span class="text-sm text-gray-300">All Categories</span>
              </label>
              <?php foreach($cats as $cat): ?>
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="category_id" value="<?= $cat['id'] ?>" <?= $filters['category_id']==$cat['id']?'checked':'' ?> class="accent-blue-500" onchange="this.form.submit()">
                <span class="text-sm text-gray-300"><?= clean($cat['name']) ?></span>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <!-- Brands -->
          <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-4">
            <h3 class="text-sm font-semibold text-white mb-3">Brands</h3>
            <div class="space-y-2 max-h-40 overflow-y-auto">
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="brand_id" value="" <?= empty($filters['brand_id'])?'checked':'' ?> class="accent-blue-500" onchange="this.form.submit()">
                <span class="text-sm text-gray-300">All Brands</span>
              </label>
              <?php foreach($brands as $b): ?>
              <label class="flex items-center gap-2 cursor-pointer">
                <input type="radio" name="brand_id" value="<?= $b['id'] ?>" <?= $filters['brand_id']==$b['id']?'checked':'' ?> class="accent-blue-500" onchange="this.form.submit()">
                <span class="text-sm text-gray-300"><?= clean($b['name']) ?></span>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <!-- Price Range -->
          <div class="rounded-xl bg-[hsl(222,47%,10%)] border border-white/5 p-4">
            <h3 class="text-sm font-semibold text-white mb-3">Price Range</h3>
            <div class="flex gap-2 items-center">
              <input type="number" name="min_price" placeholder="Min" value="<?= clean($filters['min_price']) ?>" class="w-full bg-[hsl(222,47%,13%)] border border-white/10 text-gray-300 text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:border-blue-500">
              <span class="text-gray-500 text-sm">–</span>
              <input type="number" name="max_price" placeholder="Max" value="<?= clean($filters['max_price']) ?>" class="w-full bg-[hsl(222,47%,13%)] border border-white/10 text-gray-300 text-sm rounded-lg px-2 py-1.5 focus:outline-none focus:border-blue-500">
            </div>
            <button type="submit" class="mt-2 w-full py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors">Apply</button>
          </div>

          <?php if(array_filter(array_values($filters),fn($v)=>$v!==''&&$v!=='newest')): ?>
          <a href="/products" class="block text-center py-2 text-xs text-red-400 hover:text-red-300">Clear all filters ×</a>
          <?php endif; ?>
        </form>
      </div>
    </aside>

    <!-- Products Grid -->
    <div class="flex-1">
      <!-- Header -->
      <div class="flex items-center justify-between mb-6">
        <div>
          <h1 class="text-xl font-bold text-white">
            <?= $filters['q'] ? 'Search: "'.clean($filters['q']).'"' : 'All Products' ?>
          </h1>
          <p class="text-gray-400 text-sm mt-1"><?= number_format($result['total']) ?> products found</p>
        </div>

        <!-- Search bar in content area -->
        <form action="/products" method="GET" class="hidden sm:flex gap-2">
          <?php foreach($filters as $k=>$v): if($k!=='q'&&$v!='') echo "<input type='hidden' name='{$k}' value='".clean($v)."'>"; endforeach; ?>
          <input type="text" name="q" placeholder="Search..." value="<?= clean($filters['q']) ?>"
                 class="px-3 py-1.5 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-blue-500 w-52">
          <button type="submit" class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm transition-colors">Search</button>
        </form>
      </div>

      <?php if(empty($result['items'])): ?>
      <div class="text-center py-20">
        <div class="text-6xl mb-4">🔍</div>
        <p class="text-gray-400 text-lg font-medium">No products found</p>
        <p class="text-gray-500 text-sm mt-1">Try adjusting your filters or search terms</p>
        <a href="/products" class="mt-4 inline-block px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm">Clear Filters</a>
      </div>
      <?php else: ?>

      <!-- Grid -->
      <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
        <?php foreach($result['items'] as $p): include __DIR__ . '/partials/product-card.php'; endforeach; ?>
      </div>

      <!-- Pagination -->
      <?php if($result['total_pages'] > 1): ?>
      <div class="flex items-center justify-center gap-2 mt-10">
        <?php if($result['page'] > 1): ?>
        <a href="?<?= $queryString ?>&page=<?= $result['page']-1 ?>" class="px-3 py-2 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white text-sm transition-colors">‹ Prev</a>
        <?php endif; ?>
        <?php
        $start = max(1,$result['page']-2);
        $end   = min($result['total_pages'],$result['page']+2);
        for($i=$start;$i<=$end;$i++): ?>
        <a href="?<?= $queryString ?>&page=<?= $i ?>"
           class="px-3 py-2 rounded-lg text-sm transition-colors <?= $i===$result['page']?'bg-blue-600 text-white':'bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white' ?>">
          <?= $i ?>
        </a>
        <?php endfor; ?>
        <?php if($result['page'] < $result['total_pages']): ?>
        <a href="?<?= $queryString ?>&page=<?= $result['page']+1 ?>" class="px-3 py-2 rounded-lg bg-[hsl(222,47%,12%)] border border-white/10 text-gray-300 hover:text-white text-sm transition-colors">Next ›</a>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>
</div>
