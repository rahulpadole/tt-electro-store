<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Register – <?= APP_NAME ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>tailwind.config={darkMode:'class'}</script>
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
</head>
<body class="dark bg-[hsl(222,47%,6%)] text-gray-100 min-h-screen flex items-center justify-center p-4">
<div class="toast-container fixed bottom-6 right-6 z-50 flex flex-col gap-2" id="toastContainer"></div>
<div class="w-full max-w-md">
  <div class="text-center mb-8">
    <a href="/" class="inline-flex items-center gap-2">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center"><span class="text-white font-bold">TT</span></div>
      <span class="text-white font-bold text-xl">TT <span class="text-cyan-400">ELECTRO</span></span>
    </a>
    <h1 class="text-2xl font-bold text-white mt-4">Create account</h1>
    <p class="text-gray-400 text-sm mt-1">Join the maker community</p>
  </div>
  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-8" x-data="registerForm()">
    <div class="space-y-4">
      <div><label class="text-xs text-gray-400 mb-1 block">Full Name</label>
      <input type="text" x-model="name" placeholder="John Doe" class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
      <div><label class="text-xs text-gray-400 mb-1 block">Email Address</label>
      <input type="email" x-model="email" placeholder="you@example.com" class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
      <div><label class="text-xs text-gray-400 mb-1 block">Phone (optional)</label>
      <input type="tel" x-model="phone" placeholder="+91 98765 43210" class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
      <div><label class="text-xs text-gray-400 mb-1 block">Password</label>
      <input type="password" x-model="password" placeholder="Min 6 characters" class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500"></div>
      <p x-show="error" x-text="error" class="text-red-400 text-sm bg-red-500/10 px-3 py-2 rounded-lg border border-red-500/20"></p>
      <button @click="submit()" :disabled="loading" class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all hover:scale-[1.02] disabled:opacity-50">
        <span x-show="!loading">Create Account →</span>
        <span x-show="loading" class="flex items-center justify-center gap-2"><span class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>Creating...</span>
      </button>
    </div>
    <p class="text-center text-gray-400 text-sm mt-6">Already have an account? <a href="/login" class="text-blue-400 hover:text-blue-300 font-medium">Sign in →</a></p>
  </div>
</div>
<script>
function showToast(msg,type='info'){const c=document.getElementById('toastContainer');const t=document.createElement('div');t.style.cssText='padding:.75rem 1.25rem;border-radius:.5rem;color:#fff;font-size:.875rem;background:#1e293b;border-left:4px solid '+(type==='success'?'#22c55e':'#ef4444')+';box-shadow:0 10px 30px rgba(0,0,0,.4);';t.textContent=msg;c.appendChild(t);setTimeout(()=>t.remove(),3500);}
function registerForm(){return{name:'',email:'',phone:'',password:'',loading:false,error:'',async submit(){if(!this.name||!this.email||!this.password){this.error='Please fill required fields';return;}this.loading=true;this.error='';try{await fetch('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:this.name,email:this.email,phone:this.phone,password:this.password})}).then(async r=>{const d=await r.json();if(!r.ok)throw new Error(d.message||'Registration failed');return d;});location.href='/dashboard';}catch(e){this.error=e.message;}this.loading=false;}}}
</script>
</body></html>
