<?php $pageTitle = 'Track Order'; ?>
<div class="max-w-xl mx-auto px-4 py-12" x-data="trackOrder()">
  <div class="text-center mb-8">
    <div class="text-5xl mb-3">🚚</div>
    <h1 class="text-2xl font-bold text-white">Track Your Order</h1>
    <p class="text-gray-400 text-sm mt-1">Enter your order number to see real-time status</p>
  </div>

  <div class="rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-6">
    <div class="space-y-4">
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Order Number *</label>
        <input type="text" x-model="orderNumber" placeholder="TTE-XXXXXXXX" @keydown.enter="track()"
               class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500 uppercase font-mono tracking-wide">
      </div>
      <div>
        <label class="text-xs text-gray-400 mb-1 block">Email Address (optional)</label>
        <input type="email" x-model="email" placeholder="your@email.com" @keydown.enter="track()"
               class="w-full px-4 py-3 rounded-xl bg-[hsl(222,47%,13%)] border border-white/10 text-white text-sm placeholder-gray-500 focus:outline-none focus:border-blue-500">
      </div>
      <p x-show="error" x-text="error" class="text-red-400 text-sm bg-red-500/10 px-3 py-2 rounded-lg border border-red-500/20"></p>
      <button @click="track()" :disabled="loading" class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all disabled:opacity-50">
        <span x-show="!loading">Track Order 🔍</span>
        <span x-show="loading">Searching...</span>
      </button>
    </div>
  </div>

  <!-- Result -->
  <div x-show="order" x-transition class="mt-6 rounded-2xl bg-[hsl(222,47%,10%)] border border-white/10 p-6 space-y-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-lg font-bold text-white" x-text="order?.order_number"></p>
        <p class="text-gray-500 text-sm" x-text="order ? new Date(order.created_at).toLocaleDateString('en-IN',{year:'numeric',month:'short',day:'numeric'}) : ''"></p>
      </div>
      <span class="px-3 py-1 rounded-full text-sm font-semibold capitalize"
            :class="{'bg-yellow-500/20 text-yellow-400':order?.status==='pending','bg-blue-500/20 text-blue-400':order?.status==='processing','bg-purple-500/20 text-purple-400':order?.status==='shipped','bg-green-500/20 text-green-400':order?.status==='delivered','bg-red-500/20 text-red-400':order?.status==='cancelled'}"
            x-text="order?.status"></span>
    </div>

    <div x-show="order?.tracking_number" class="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20">
      <p class="text-xs text-gray-400">Tracking Number</p>
      <p class="text-blue-400 font-mono font-bold" x-text="order?.tracking_number"></p>
    </div>

    <!-- Timeline -->
    <div x-show="order?.status_timeline?.length">
      <p class="text-sm font-semibold text-white mb-3">Status Timeline</p>
      <div class="space-y-3">
        <template x-for="(t,i) in [...(order?.status_timeline||[])].reverse()" :key="i">
          <div class="flex items-start gap-3">
            <div class="w-2 h-2 rounded-full bg-blue-500 mt-1.5 flex-shrink-0"></div>
            <div>
              <p class="text-sm font-medium text-white" x-text="t.label||t.status"></p>
              <p class="text-xs text-gray-500" x-text="new Date(t.time).toLocaleString('en-IN')"></p>
            </div>
          </div>
        </template>
      </div>
    </div>

    <div class="text-center pt-2">
      <a :href="'/orders/'+order?.id" class="text-blue-400 hover:text-blue-300 text-sm">View Full Order Details →</a>
    </div>
  </div>
</div>
<script>
function trackOrder() {
  return {
    orderNumber: '', email: '', loading: false, error: '', order: null,
    async track() {
      if(!this.orderNumber.trim()) { this.error='Please enter an order number'; return; }
      this.loading=true; this.error=''; this.order=null;
      try {
        const d = await apiFetch('/api/orders/track', { method:'POST', body:JSON.stringify({ order_number:this.orderNumber.toUpperCase(), email:this.email }) });
        this.order = d.data;
      } catch(e) { this.error=e.message; }
      this.loading=false;
    }
  }
}
</script>
