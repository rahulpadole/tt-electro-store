<?php
$pageTitle = 'Wishlist';
$wm = new WishlistModel();
$items = $wm->getForUser(getCurrentUserId());
?>
<div class="max-w-7xl mx-auto px-4 py-8">
  <h1 class="text-2xl font-bold text-white mb-6">My Wishlist <span class="text-gray-500 text-lg font-normal">(<?= count($items) ?>)</span></h1>
  <?php if(empty($items)): ?>
  <div class="text-center py-20">
    <div class="text-7xl mb-4">🤍</div>
    <p class="text-gray-400 text-lg font-medium mb-2">Your wishlist is empty</p>
    <p class="text-gray-500 text-sm mb-6">Save products you love to find them later</p>
    <a href="/products" class="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-all">Browse Products →</a>
  </div>
  <?php else: ?>
  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
    <?php foreach($items as $item): ?>
    <div class="group relative rounded-2xl bg-[hsl(222,47%,10%)] border border-white/5 hover:border-pink-500/20 overflow-hidden transition-all hover:-translate-y-1 flex flex-col">
      <a href="/products/<?= $item['product_id'] ?>" class="block relative overflow-hidden">
        <?php if($item['thumbnail']): ?>
        <img src="<?= clean($item['thumbnail']) ?>" alt="<?= clean($item['name']) ?>" class="w-full h-44 object-cover group-hover:scale-105 transition-transform duration-500">
        <?php else: ?>
        <div class="w-full h-44 bg-gradient-to-br from-pink-900/20 to-blue-900/20 flex items-center justify-center text-5xl">📦</div>
        <?php endif; ?>
      </a>
      <div class="p-3 flex flex-col flex-1">
        <a href="/products/<?= $item['product_id'] ?>" class="text-sm font-medium text-gray-200 hover:text-white line-clamp-2 flex-1"><?= clean($item['name']) ?></a>
        <div class="mt-2">
          <span class="text-base font-bold text-white">₹<?= number_format((float)(($item['is_flash_sale']&&$item['flash_sale_price'])?$item['flash_sale_price']:$item['price']),2) ?></span>
          <?php if($item['original_price']&&(float)$item['original_price']>(float)$item['price']): ?><span class="text-xs text-gray-500 line-through ml-1">₹<?= number_format((float)$item['original_price'],2) ?></span><?php endif; ?>
        </div>
        <div class="flex gap-2 mt-2">
          <button onclick="addToCart(<?= $item['product_id'] ?>)" class="flex-1 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors">Add to Cart</button>
          <button onclick="removeWishlist(<?= $item['product_id'] ?>,this)" class="p-1.5 rounded-lg border border-white/10 hover:border-red-500/30 hover:bg-red-500/10 text-gray-400 hover:text-red-400 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
          </button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<script>
async function removeWishlist(productId, btn) {
  try {
    await apiFetch(`/api/wishlist/${productId}`, { method: 'DELETE' });
    btn.closest('.group').remove();
    showToast('Removed from wishlist', 'success');
  } catch(e) { showToast(e.message, 'error'); }
}
</script>
